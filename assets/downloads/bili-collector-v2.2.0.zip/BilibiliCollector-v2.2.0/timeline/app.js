/* ==========================================================================
   信息摄入时间线 —— markwhen 风格
   横轴：时间   纵轴：大类   每类一条泳道，密度成条，进展成点
   ========================================================================== */
(function () {
'use strict';

const DATA = window.TIMELINE_DATA;
const DAY = 86400000;
const LABEL_W = 142;
const LANE_H = 74;

/* 卡片视图：放大到能一条条看清时，用「封面 + 标题」代替密度柱条 */
const CARD_W = 112;
const CARD_H = 112;
const CARD_GAP = 7;
const MAX_LAYERS = 4;   // 一个泳道最多叠几层；超过说明还是太密，退回密度视图
const MIN_WIN = 86400000;   // 最近能放到 1 天 —— 够看到某一天的每一条

const $ = (id) => document.getElementById(id);
const el = (tag, cls) => { const d = document.createElement(tag); if (cls) d.className = cls; return d; };
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------------------------------------------------------- 时间工具 */

const pad = (n) => String(n).padStart(2, '0');
/* 日期一律按「本地时区」读：桶是按本地日期（本地午夜）建的时间戳，
   用 UTC 读会在东八区整体偏早一天 —— 6/8 的进展会标成 6/7。 */
function fmtDay(ms) {
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function monthLabel(m) {
  const [y, mm] = m.split('-');
  return showYear() ? `${y} 年 ${+mm} 月` : `${+mm} 月`;
}

/* 桶的绝对时间（前端只认 b.t，不反解 key） */
const bTs = (b) => b.t * 1000;
const unitMs = () => SRC().unit * 1000;

/* 数据源跨年时才需要在标签里带上年份 */
const showYear = () => !!SRC()._multi;

function bucketLabel(b) {
  const d = new Date(bTs(b));
  if (SRC().grain === 'd') return `${d.getMonth() + 1} 月 ${d.getDate()} 日`;
  return showYear()
    ? `${b.w.slice(0, 4)} 年第 ${+b.w.slice(6)} 周`
    : `第 ${+b.w.slice(6)} 周`;
}

function bucketRange(b) {
  const a = new Date(bTs(b));
  const y = showYear() ? `${a.getFullYear()}/` : '';
  if (SRC().grain === 'd') {
    return showYear() ? fmtDay(bTs(b)) : `${a.getMonth() + 1}/${a.getDate()}`;
  }
  const e = new Date(bTs(b) + 6 * 86400000);
  const same = a.getMonth() === e.getMonth();
  return same
    ? `${y}${a.getMonth() + 1}/${a.getDate()} – ${e.getDate()}`
    : `${y}${a.getMonth() + 1}/${a.getDate()} – ${e.getMonth() + 1}/${e.getDate()}`;
}

/* 进展 chip 上的「时间」小字。
   年份在这张图上基本是噪音 —— 整条轴都落在同一年，每个 chip 都挂个「2026」
   等于什么都没说；所以只写月份：日粒度写「8/12」，周粒度写「8月」，
   只有真的跨年（小红书那种）才补两位年份区分。 */
function evWhen(ev) {
  const d = new Date(ev.t * 1000);
  const m = d.getMonth() + 1;
  if (SRC()._multi) return `${String(d.getFullYear()).slice(2)}/${m}`;
  return SRC().grain === 'd' ? `${m}/${d.getDate()}` : `${m}月`;
}

/* 桶的「什么时候」，按粒度给一句完整表述（不要同一天写两遍） */
function bucketWhen(b) {
  if (SRC().grain === 'd') return bucketLabel(b);              // 6 月 30 日
  return `${bucketRange(b)} · 第 ${+b.w.slice(6)} 周`;          // 2025/3/10 – 16 · 第 12 周
}

/* ---------------------------------------------------------- 状态 */

const S = {
  si: 0,            // 当前数据源
  f0: 0, f1: 0,     // 全范围
  t0: 0, t1: 0,     // 视图范围
  lane: null,       // 高亮的泳道 key
  sel: null,        // 选中的桶 {lk, wk}
  q: '',
  showEv: true,
  focus: true,      // 默认只看数据密集的主线区间
  monthAll: false,
};

const IDX = new Map();   // `${si}|${laneKey}|${week}` -> {lane, b}

/* ---------------------------------------------------------- 预处理 */

function prep() {
  DATA.sources.forEach((s, si) => {
    let lo = Infinity, hi = -Infinity;
    const all = [];
    const years = new Set();
    s.lanes.forEach((l) => {
      l.buckets.forEach((b) => {
        const ts = bTs(b);
        if (ts < lo) lo = ts;
        if (ts + s.unit * 1000 > hi) hi = ts + s.unit * 1000;
        all.push(ts);
        years.add(new Date(ts).getFullYear());
        IDX.set(`${si}|${l.key}|${b.w}`, { lane: l, b });
      });
    });
    s._lo = lo === Infinity ? Date.now() : lo;
    s._hi = hi === -Infinity ? Date.now() : hi;
    // 90% 数据所在区间，供"聚焦主线"使用
    all.sort((a, b) => a - b);
    s._p5 = all.length ? all[Math.floor(all.length * 0.05)] : s._lo;
    s._p95 = all.length ? all[Math.floor(all.length * 0.95)] : s._hi;
    // 只覆盖一个年份时，年份是噪音（每个标注都挂个"2026"），全局隐去
    s._years = years;
    s._multi = years.size > 1;

    // 每条泳道再摊平一份按时间升序的条目表 —— 放大后要按「条目」而非「桶」定位，
    // 二分找视口范围，避免每次重排都扫全量。
    s.lanes.forEach((l) => {
      const flat = [];
      l.buckets.forEach((b) => { for (const it of b.items) flat.push(it); });
      flat.sort((a, b) => a.ts - b.ts);
      l._items = flat;
    });
  });
}

const SRC = () => DATA.sources[S.si];
const trackW = () => Math.max(120, $('tl-canvas').clientWidth - LABEL_W);
const X = (ts) => (ts - S.t0) / (S.t1 - S.t0) * trackW();

/* ---------------------------------------------------------- 刻度 */

/* 放大到月以内时用的固定间隔刻度（锚点落在本地整点 / 本地零点上） */
const TICK_STEPS = [
  [2 * 3600e3, 'hh'], [6 * 3600e3, 'hh'], [12 * 3600e3, 'hh'],
  [86400e3, 'dd'], [2 * 86400e3, 'dd'], [7 * 86400e3, 'dd'], [14 * 86400e3, 'dd'],
];

/* 刻度的第一个锚点。一律从「本地零点」按步长往前推：
   桶是按本地日期建的，按 UTC 对齐（直接整除或 Date.UTC）在东八区会整列歪 8 小时，
   日刻度落到早上 8 点；而踩在零点上，一天里至少有一根刻度能直接写出日期。 */
function tickAnchor(t0, ms) {
  const d = new Date(t0);
  d.setHours(0, 0, 0, 0);
  const base = d.getTime();
  return base + Math.max(0, Math.ceil((t0 - base) / ms)) * ms;
}

function makeTicks() {
  const W = trackW();
  const pxDay = W / ((S.t1 - S.t0) / 86400000);

  // 视野窄到两个月以内：按「天/小时」铺刻度。再往下走月份刻度会稀到只剩一两根，
  // 深放大看单条内容时尺子就废了。
  if (pxDay >= 18) {
    for (const [ms, kind] of TICK_STEPS) {
      if (ms * pxDay / 86400000 < 58) continue;      // 太挤，换更大的间隔
      const out = [];
      for (let t = tickAnchor(S.t0, ms); t <= S.t1 && out.length < 300; t += ms) {
        const dd = new Date(t);
        const h = dd.getHours();
        const md = `${dd.getMonth() + 1}/${dd.getDate()}`;
        out.push({
          ts: t,
          // 小时级的视图里零点直接写日期，否则一屏的「00:00」看不出跨到了哪天
          label: kind === 'hh' ? (h === 0 ? md : `${pad(h)}:00`) : md,
          major: kind === 'hh' ? h === 0 : dd.getDate() === 1,
        });
      }
      if (out.length) return out;
    }
  }

  // 阈值按「一格至少要占 150px」推：月 30 天 → 5，季 90 天 → 1.7
  const mode = pxDay > 5 ? 'month' : pxDay > 1.7 ? 'quarter' : 'year';
  const stepM = mode === 'month' ? 1 : mode === 'quarter' ? 3 : 12;

  const d = new Date(S.t0);
  let y = d.getFullYear();
  let m = Math.floor(d.getMonth() / stepM) * stepM;

  const out = [];
  for (let guard = 0; guard < 400; guard++) {
    const ts = new Date(y, m, 1).getTime();
    if (ts > S.t1) break;
    if (ts >= S.t0 - 86400000) {
      const isJan = m === 0;
      let label;
      if (mode === 'year') label = `${y}`;
      else if (isJan) label = showYear() ? `${y} 年` : '1 月';
      else label = mode === 'quarter' ? `Q${m / 3 + 1}` : `${m + 1} 月`;
      out.push({ ts, label, major: isJan, mode });
    }
    m += stepM;
    if (m >= 12) { m -= 12; y++; }
  }
  return out;
}

/* ---------------------------------------------------------- 卡片视图 */

/* 视口内的条目 —— 用二分定位，别每次重排都扫全量 */
function viewItems(lane) {
  const arr = lane._items;
  if (!arr || !arr.length) return [];
  const lo = S.t0 / 1000, hi = S.t1 / 1000;
  let a = 0, b = arr.length;
  while (a < b) {
    const m = (a + b) >> 1;
    if (arr[m].ts < lo) a = m + 1; else b = m;
  }
  const out = [];
  for (let i = a; i < arr.length && arr[i].ts <= hi; i++) out.push(arr[i]);
  return out;
}

/* 按「互不重叠」把条目铺进若干层：每条找第一个还放得下的层。
   需要的层数超过 MAX_LAYERS 就直接放弃（返回 null），让泳道退回密度视图。 */
function packCards(list, W) {
  const ends = [];
  const cards = [];
  for (const it of list) {
    const x = X(it.ts * 1000);
    if (x > W || x < -CARD_W) continue;
    let li = 0;
    while (li < ends.length && x < ends[li] + CARD_GAP) li++;
    if (li >= MAX_LAYERS) return null;
    ends[li] = x + CARD_W;
    cards.push({ it, x, li });
  }
  if (!cards.length) return null;
  return { cards, layers: ends.length };
}

function itemUrlOf(it) {
  return SRC().key === 'bilibili'
    ? `https://www.bilibili.com/video/${it.u}`
    : `https://www.xiaohongshu.com/explore/${it.u}`;
}

function cardEl(it) {
  const a = el('a', 'card');
  a.href = itemUrlOf(it);
  a.target = '_blank';
  a.rel = 'noopener';
  a.title = it.t;
  if (S.q) a.classList.toggle('hit', itemHits(it));
  // 小红书有约 1/3 的封面已被作者删除（图床直接 404），加载失败就退回色块占位
  a.innerHTML =
    `<span class="card-pic">` +
      (it.p ? `<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(it.p)}" alt="">` : '') +
      `<span class="card-ph">${esc((it.t || '·').slice(0, 1))}</span>` +
    `</span>` +
    `<span class="card-t">${esc(it.t)}</span>` +
    `<span class="card-a">${esc(it.a || it.sub || '')}</span>`;
  const img = a.querySelector('img');
  if (img) img.onerror = () => { img.remove(); a.querySelector('.card-pic').classList.add('none'); };
  return a;
}

/* ---------------------------------------------------------- 顶栏 */

function renderTopbar() {
  const sw = $('src-switch');
  sw.innerHTML = '';
  DATA.sources.forEach((s, i) => {
    const b = el('button', i === S.si ? 'on' : '');
    b.innerHTML = `<span class="dot"></span>${esc(s.label)}`;
    b.onclick = () => setSource(i);
    sw.appendChild(b);
  });

  const s = SRC();
  $('brand-sub').textContent = `· ${s.file.replace(/\.json$/, '')}`;

  const days = Math.round((s._hi - s._lo) / 86400000);
  const span = days > 400 ? `${(days / 365).toFixed(1)} 年` : `${days} 天`;
  $('stat-row').innerHTML = `
    <div class="stat"><span class="stat-v">${s.total.toLocaleString()}</span><span class="stat-k">条目</span></div>
    <div class="stat"><span class="stat-v">${s.lanes.length}</span><span class="stat-k">大类</span></div>
    <div class="stat"><span class="stat-v">${span}</span><span class="stat-k">跨度</span></div>`;
}

/* ---------------------------------------------------------- 泳道渲染 */

function renderRuler() {
  const r = $('ruler');
  r.innerHTML = '';
  if (!S.t1) return;
  const W = trackW();
  const ticks = makeTicks();

  // 视图起点往往落在月中，第一个刻度会离左边很远，补一个起点标签方便定位
  if (!ticks.length || X(ticks[0].ts) > 54) {
    const d = new Date(S.t0);
    ticks.unshift({
      ts: S.t0,
      label: `${d.getMonth() + 1}/${d.getDate()}`,
      major: true,
    });
  }

  ticks.forEach((t) => {
    const x = X(t.ts);
    if (x < -40 || x > W + 40) return;
    const d = el('div', 'tick' + (t.major ? ' major' : ''));
    // ruler 有 padding-left，而 absolute 定位相对于 padding box，所以要手动补上标签列宽
    d.style.left = (LABEL_W + x) + 'px';
    d.textContent = t.label;
    r.appendChild(d);
  });
}

function renderLanes() {
  const wrap = $('lanes');
  const board = $('board');
  // 重建 #lanes 的瞬间 scrollHeight 会塌成 0，浏览器顺手把 scrollTop 钳回顶部 ——
  // 表现就是「在卡片视图里滚下去看某条泳道，一横滑/一缩放就跳回最上面」。
  // 所以先记下纵向位置，重建完再放回去（内容变矮了就按新上限夹一下）。
  const keepTop = board.scrollTop;
  wrap.innerHTML = '';
  hideTip();          // 重排后旧的悬停提示会挂在屏幕上，先收掉
  if (!S.t1) return;

  const ticks = makeTicks();
  const W = trackW();
  const src = SRC();
  // 柱高用全局最大值归一化：否则只有两三条的小类会和大类显得一样活跃
  const gmax = Math.max(1, ...src.lanes.flatMap((l) => l.buckets.map((b) => b.n)));
  let hits = 0;

  src.lanes.forEach((lane) => {
    const row = el('div', 'lane-row');
    row.style.setProperty('--c', lane.color);
    if (S.lane === lane.key) row.classList.add('on');
    else if (S.lane) row.classList.add('dim');

    /* --- 标签 */
    const lab = el('div', 'lane-label');
    lab.innerHTML =
      `<span class="lane-chip"></span>
       <span class="lane-meta">
         <span class="lane-name">${esc(lane.name)}</span>
         <span class="lane-count">${lane.total.toLocaleString()} 条</span>
       </span>`;
    lab.onclick = () => { S.lane = S.lane === lane.key ? null : lane.key; S.sel = null; renderAll(); };
    row.appendChild(lab);

    /* --- 轨道 */
    const track = el('div', 'lane-track');
    if (S.q) track.classList.add('searching');

    ticks.filter((t) => t.major).forEach((t) => {
      const g = el('div', 'grid-v strong');
      g.style.left = X(t.ts) + 'px';
      track.appendChild(g);
    });

    /* --- 够稀疏就切成卡片视图：一条一条看得到封面和标题 --- */
    const packed = packCards(viewItems(lane), W);
    if (packed) {
      row.classList.add('cards');
      row.style.height = (packed.layers * (CARD_H + CARD_GAP) + 14) + 'px';
      packed.cards.forEach(({ it, x, li }) => {
        const c = cardEl(it);
        if (S.q && itemHits(it)) hits++;
        c.style.left = x + 'px';
        c.style.top = (li * (CARD_H + CARD_GAP) + 7) + 'px';
        track.appendChild(c);
      });
      row.appendChild(track);
      wrap.appendChild(row);
      return;
    }

    const maxN = Math.max(1, ...lane.buckets.map((b) => b.n));
    const unit = unitMs();

    lane.buckets.forEach((b) => {
      const ts = bTs(b);
      const x = X(ts);
      const rawW = X(ts + unit) - x;
      if (x > W + rawW + 30 || x + rawW < -30) return;

      const laneRatio = b.n / maxN;
      const h = 6 + 30 * Math.pow(b.n / gmax, 0.42);
      // 视野很宽时一个桶会拉得很长，限制宽度并居中，保持"数据点"的观感
      const gap = rawW > 4 ? 1 : 0;
      const wpx = Math.max(1.5, Math.min(rawW - gap, 44));
      const left = x + Math.max(0, (rawW - wpx) / 2);

      const bar = el('div', 'bar');
      bar.style.left = left + 'px';
      bar.style.width = wpx + 'px';
      bar.style.height = h + 'px';
      bar.style.bottom = '9px';
      bar.style.opacity = (0.30 + 0.70 * Math.pow(laneRatio, 0.5)).toFixed(3);

      if (S.sel && S.sel.lk === lane.key && S.sel.wk === b.w) bar.classList.add('sel');
      if (S.q && bucketHits(b)) { bar.classList.add('hit'); hits++; }

      bar.onmouseenter = (e) => showTip(e, lane, b);
      bar.onmousemove = (e) => moveTip(e);
      bar.onmouseleave = hideTipSoon;
      bar.onclick = (e) => {
        e.stopPropagation();
        S.sel = { lk: lane.key, wk: b.w };
        renderLanes(); renderDrawer();
      };
      track.appendChild(bar);
    });

    /* --- 进展标注 */
    if (S.showEv && lane.progress && lane.progress.length) {
      const CJK = /[\u4e00-\u9fa5]/;
      const cand = [];

      lane.progress.forEach((ev) => {
        const x = X(ev.t * 1000);
        if (x < 2 || x > W) return;
        const top = ev.topics[0];
        if (!top) return;
        const text = top[0];
        let cjk = 0;
        for (const ch of text) if (CJK.test(ch)) cjk++;
        const when = evWhen(ev);
        // chip 宽度估算（含内边距与右侧时间小字）
        const est = cjk * 10.6 + (text.length - cjk) * 6.4 + when.length * 6.2 + 13;
        if (x + est > W) return;                                   // 贴右边会被裁
        cand.push({ ev, x, est, when, weight: top[1] });
      });

      // 话题权重高的优先占位，否则密集时段会把重要话题挤掉
      cand.sort((a, b) => b.weight - a.weight);
      const placed = [];
      cand.forEach((c) => {
        const hit = placed.some((p) => c.x < p.x + p.est + 7 && p.x < c.x + c.est + 7);
        if (!hit) placed.push(c);
      });
      placed.sort((a, b) => a.x - b.x);

      placed.forEach(({ ev, x, when }) => {
        const chip = el('div', 'ev');
        chip.style.left = x + 'px';
        chip.style.top = '6px';
        chip.innerHTML =
          `<span class="ev-chip">${esc(ev.topics[0][0])}` +
          `<span class="when">${when}</span>` +
          `</span>`;
        chip.style.pointerEvents = 'auto';
        chip.onmouseenter = (e) => showProgressTip(e, lane, ev);
        chip.onmousemove = (e) => moveTip(e);
        chip.onmouseleave = hideTipSoon;
        track.appendChild(chip);
      });
    }

    row.appendChild(track);
    wrap.appendChild(row);
  });

  const qc = $('q-count');
  if (S.q) {
    qc.textContent = hits ? `${hits} 处` : '无结果';
    qc.classList.toggle('none', !hits);
  } else {
    qc.textContent = '';
    qc.classList.remove('none');
  }

  board.scrollTop = Math.min(keepTop, Math.max(0, board.scrollHeight - board.clientHeight));
}

/* ---------------------------------------------------------- 全览条 */

function renderOverview() {
  const N = 120;
  const s = SRC();
  const arr = new Array(N).fill(0);
  const span = s._hi - s._lo || 1;

  s.lanes.forEach((l) => l.buckets.forEach((b) => {
    const i = Math.floor((bTs(b) - s._lo) / span * N);
    if (i >= 0 && i < N) arr[i] += b.n;
  }));

  const mx = Math.max(1, ...arr);
  const bars = $('ov-bars');
  bars.innerHTML = '';
  arr.forEach((v) => {
    const d = el('div', 'ov-bar');
    d.style.height = Math.max(1, (v / mx) * 20) + 'px';
    d.style.opacity = v ? (0.3 + 0.6 * (v / mx)).toFixed(2) : '0';
    bars.appendChild(d);
  });

  const win = $('ov-win');
  const a = (S.t0 - s._lo) / span, b2 = (S.t1 - s._lo) / span;
  win.style.left = (a * 100) + '%';
  win.style.width = (Math.max(0.012, b2 - a) * 100) + '%';

  const d0 = new Date(S.t0), d1 = new Date(S.t1);
  const range = showYear()
    ? `${fmtDay(S.t0)} → ${fmtDay(S.t1)}`
    : `${d0.getMonth() + 1}/${d0.getDate()} → ${d1.getMonth() + 1}/${d1.getDate()}`;
  $('ov-hint').textContent = `${range} · 左右拖动平移 · ⌘滚轮缩放 · 双击复位`;
}

/* ---------------------------------------------------------- Tooltip */

const TIP = $('tip');

/* 富文本条目：封面上有图就显示图，没有就退回色块 + 首字 */
function tipCard(it) {
  // 两家图床都拒外站 Referer（403），必须显式不带 —— 否则封面全军覆没
  const pic = it.p
    ? `<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(it.p)}" alt="">` : '';
  return `<a class="tip-card" href="${itemUrlOf(it)}" target="_blank" rel="noopener">
      <span class="tip-pic">${pic}<span class="tip-ph">${esc((it.t || '·').slice(0, 1))}</span></span>
      <span class="tip-body">
        <span class="tip-t">${esc(it.t)}</span>
        <span class="tip-a">${esc(it.a || it.sub || '')}</span>
      </span>
    </a>`;
}

function tipShell(color, title, count, terms, items, more) {
  const t = terms && terms.length
    ? `<div class="tip-terms">${terms.map((x) => `<span>${esc(x[0])}</span>`).join('')}</div>` : '';
  const li = items && items.length
    ? (items[0] && items[0].p !== undefined
        ? `<div class="tip-cards">${items.map(tipCard).join('')}</div>`
        : `<div class="tip-sep"></div>` + items.map(
            (i) => `<div class="tip-item"><span>${esc(i.t)}</span></div>`).join(''))
    : '';
  const m = more ? `<div class="tip-more">${more}</div>` : '';
  TIP.innerHTML = `
    <div class="tip-h">
      <span class="lane-chip" style="background:${color}"></span>
      <span class="tip-date">${title}</span>
      <span class="tip-n" style="--c:${color}">${count}</span>
    </div>${t}${li}${m}`;
  TIP.querySelectorAll('.tip-card img').forEach((im) => {
    im.onerror = () => { im.remove(); im.parentNode.classList.add('none'); };
  });
}

function showTip(e, lane, b) {
  TIP.style.setProperty('--c', lane.color);
  tipShell(lane.color, bucketWhen(b),
    b.n + ' 条', b.terms, b.items.slice(0, 4),
    b.items.length > 4 ? `… 共 ${b.n} 条，点击查看全部` : '点击查看全部');
  TIP.classList.add('on');
  moveTip(e);
}

function showProgressTip(e, lane, ev) {
  TIP.style.setProperty('--c', lane.color);
  const items = ev.topics.map((t) => ({ t: `${t[0]}  ·  出现 ${t[1]} 次` }));
  tipShell(lane.color, bucketLabel(ev), '新话题', null, items, '首次进入视野的话题');
  TIP.classList.add('on');
  moveTip(e);
}

function moveTip(e) {
  const r = TIP.getBoundingClientRect();
  let x = e.clientX + 14, y = e.clientY + 16;
  if (x + r.width > innerWidth - 10) x = e.clientX - r.width - 14;
  if (y + r.height > innerHeight - 10) y = e.clientY - r.height - 16;
  TIP.style.left = Math.max(6, x) + 'px';
  TIP.style.top = Math.max(6, y) + 'px';
}
function hideTip() { clearTimeout(tipTimer); TIP.classList.remove('on'); }

/* 卡片刻意不立刻收：留一点时间让鼠标移进 tooltip 里点开链接 */
let tipTimer = null;
function hideTipSoon() {
  clearTimeout(tipTimer);
  tipTimer = setTimeout(() => TIP.classList.remove('on'), 220);
}
function keepTip() { clearTimeout(tipTimer); }

/* ---------------------------------------------------------- 抽屉 */

function itemUrl(s, item) {
  return s.key === 'bilibili'
    ? `https://www.bilibili.com/video/${item.u}`
    : `https://www.xiaohongshu.com/explore/${item.u}`;
}

/* 抽屉里的条目：封面 + 标题 + 作者，点开就是原站 */
function itemCardHtml(s, i) {
  const pic = i.p
    ? `<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(i.p)}" alt="">` : '';
  return `<a class="item" href="${itemUrl(s, i)}" target="_blank" rel="noopener">
      <span class="item-pic">${pic}<span class="item-ph">${esc((i.t || '·').slice(0, 1))}</span></span>
      <span class="item-body">
        <span class="item-t">${esc(i.t)}</span>
        <span class="item-m">${esc(i.a)}${i.sub ? `<span class="sub">${esc(i.sub)}</span>` : ''}</span>
      </span>
    </a>`;
}

/* 封面可能已被作者删除（图床 404），挂掉就退回色块 + 首字 */
function wireItemCards(root) {
  root.querySelectorAll('.item-pic img, .tip-pic img').forEach((im) => {
    im.onerror = () => { im.remove(); im.parentNode.classList.add('none'); };
  });
}

let drawerWasOpen = false;

/* 抽屉开合会改变时间线可用宽度，状态变化时重排一次 */
function syncDrawer(open) {
  $('drawer').classList.toggle('open', open);
  document.body.classList.toggle('drawer-open', open);
  if (open !== drawerWasOpen) {
    drawerWasOpen = open;
    requestAnimationFrame(() => {
      fitLaneHeight(); renderRuler(); renderLanes(); renderOverview();
    });
  }
}

/* 把视图拉到某一周附近 */
function focusWeek(laneKey, wk) {
  const s = SRC();
  const rec = IDX.get(`${S.si}|${laneKey}|${wk}`);
  if (!rec) return;
  const ts = bTs(rec.b);
  S.lane = laneKey;
  const half = 14 * (SRC().unit * 1000);
  setWin(Math.max(s._lo, ts - half), Math.min(s._hi, ts + half));
}

function renderDrawer() {
  const d = $('drawer');
  const head = $('drawer-head');
  const body = $('drawer-body');
  const s = SRC();

  /* ---------- 某一周某一类的详情 ---------- */
  if (S.sel) {
    const rec = IDX.get(`${S.si}|${S.sel.lk}|${S.sel.wk}`);
    if (!rec) { syncDrawer(false); return; }
    const { lane, b } = rec;
    d.style.setProperty('--c', lane.color);
    head.innerHTML = `
      <span class="lane-chip" style="background:${lane.color}"></span>
      <div>
        <div class="drawer-title">${esc(lane.name)} · ${b.n} 条</div>
        <div class="drawer-sub">${bucketWhen(b)}</div>
      </div>
      <button class="drawer-close" id="d-close">✕</button>`;
    body.innerHTML =
      `<div class="sec"><div class="sec-t">这段时间的主题</div>
        <div class="terms">${b.terms.map((t) =>
          `<span class="term">${esc(t[0])}<small>${t[1]}</small></span>`).join('')
          || '<span class="drawer-sub">—</span>'}</div>
       </div>
       <div class="sec"><div class="sec-t">内容 · ${b.n} 条</div>
        ${b.items.map((i) => itemCardHtml(s, i)).join('')}
       </div>`;
    syncDrawer(true);
    wireItemCards(body);
    $('d-close').onclick = () => { S.sel = null; renderLanes(); renderDrawer(); };
    return;
  }

  /* ---------- 某一大类的进展线 ---------- */
  if (S.lane) {
    const lane = s.lanes.find((l) => l.key === S.lane);
    if (!lane) { syncDrawer(false); return; }
    d.style.setProperty('--c', lane.color);

    const subs = lane.subs.map(([n, c]) =>
      `<span class="term">${esc(n)}<small>${c}</small></span>`).join('');

    const progCards = lane.progress.map((ev) => {
      const rec = IDX.get(`${S.si}|${lane.key}|${ev.w}`);
      return `<div class="month-card jump" data-week="${ev.w}" data-lane="${lane.key}">
        <div class="month-h">
          <span class="month-m">${bucketLabel(ev)}</span>
          <span class="month-n">${rec ? rec.b.n + ' 条' : ''}</span>
        </div>
        <div class="terms">${ev.topics.map((t) =>
          `<span class="term">${esc(t[0])}<small>${t[1]}</small></span>`).join('')}</div>
      </div>`;
    }).join('');

    const months = S.monthAll ? lane.monthly : lane.monthly.slice(-10);
    const monthCards = months.map((m) => `
      <div class="month-card">
        <div class="month-h">
          <span class="month-m">${monthLabel(m.m)}</span>
          <span class="month-n">${m.n} 条</span>
        </div>
        <div class="terms">${m.terms.map((t) => `<span>${esc(t[0])}</span>`).join('')}</div>
      </div>`).join('');

    head.innerHTML = `
      <span class="lane-chip" style="background:${lane.color}"></span>
      <div>
        <div class="drawer-title">${esc(lane.name)}</div>
        <div class="drawer-sub">${lane.total.toLocaleString()} 条 · 进展线</div>
      </div>
      <button class="drawer-close" id="d-close">✕</button>`;

    body.innerHTML = `
      <div class="sec"><div class="sec-t">构成</div><div class="terms">${subs}</div></div>
      <div class="sec">
        <div class="sec-t">进展线 · 话题首次进入视野</div>
        ${progCards || '<div class="drawer-sub">这一类的话题比较分散，没有明显的主线</div>'}
      </div>
      <div class="sec">
        <div class="sec-t">逐月 ${lane.monthly.length > 10 && !S.monthAll ?
          `<button class="more-btn" id="d-more">展开全部 ${lane.monthly.length} 个月</button>` :
          (lane.monthly.length > 10 ? `<button class="more-btn" id="d-more">收起</button>` : '')}</div>
        ${monthCards}
      </div>`;

    syncDrawer(true);
    $('d-close').onclick = () => { S.lane = null; renderAll(); };
    const mb = $('d-more');
    if (mb) mb.onclick = (e) => { e.stopPropagation(); S.monthAll = !S.monthAll; renderDrawer(); };

    body.querySelectorAll('.jump').forEach((elm) => {
      elm.onclick = () => {
        focusWeek(elm.dataset.lane, elm.dataset.week);
        renderDrawer();
      };
    });
    return;
  }

  syncDrawer(false);
}

/* ---------------------------------------------------------- 搜索 */

function bucketHits(b) {
  const q = S.q;
  if (!q) return false;
  if (b.terms.some((t) => t[0].toLowerCase().includes(q))) return true;
  return b.items.some((i) => (i.t || '').toLowerCase().includes(q));
}

function itemHits(it) {
  return !!S.q && ((it.t || '').toLowerCase().includes(S.q) ||
                   (it.a || '').toLowerCase().includes(S.q));
}

/* ---------------------------------------------------------- 全览交互 */

let drag = null;

function setupOverview() {
  const track = $('ov-track');
  const win = $('ov-win');

  const pctAt = (e) => {
    const r = track.getBoundingClientRect();
    return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
  };

  win.addEventListener('mousedown', (e) => {
    e.preventDefault(); e.stopPropagation();
    const s = SRC(), span = s._hi - s._lo;
    drag = { mode: 'move', startX: e.clientX, w0: (S.t1 - S.t0) / span, a0: (S.t0 - s._lo) / span,
             rect: track.getBoundingClientRect() };
  });

  track.addEventListener('mousedown', (e) => {
    if (drag) return;
    const s = SRC(), span = s._hi - s._lo;
    const p = pctAt(e);
    // 放大到只剩十几天时窗口只有十几像素宽，根本抠不住 —— 贴近它左右边缘 ±10px 也算拖它
    const wr = win.getBoundingClientRect();
    if (Math.abs(e.clientX - wr.left) <= 10 || Math.abs(e.clientX - wr.right) <= 10) {
      e.preventDefault();
      drag = { mode: 'move', startX: e.clientX, w0: (S.t1 - S.t0) / span, a0: (S.t0 - s._lo) / span,
               rect: track.getBoundingClientRect() };
      return;
    }
    const half = Math.min(0.5, (S.t1 - S.t0) / span / 2);
    setWin((p - half) * span + s._lo, (p + half) * span + s._lo);
  });

  window.addEventListener('mousemove', (e) => {
    if (!drag) return;
    const s = SRC(), span = s._hi - s._lo;
    const d = (e.clientX - drag.startX) / drag.rect.width;
    const a = Math.min(Math.max(0, drag.a0 + d), 1 - drag.w0);
    const w = drag.w0 * span;
    S.t0 = a * span + s._lo;
    S.t1 = S.t0 + w;
    renderLanes(); renderRuler(); renderOverview();
  });
  window.addEventListener('mouseup', () => { drag = null; });

  track.addEventListener('wheel', (e) => {
    e.preventDefault();
    zoomAt(pctAt(e), e.deltaY > 0 ? 1.25 : 0.8);
  }, { passive: false });

  // 主区滚轮分三种走法：
  //   横向占主导（触控板左右滑、Shift+滚轮）→ 平移时间轴
  //   ⌘/Ctrl + 滚轮 → 以指针为锚点缩放（触控板捏合会带 ctrlKey，正好接上）
  //   其余（含纵向占主导的斜向手势）→ 交回浏览器做纵向滚动，卡片视图下泳道会变高，得能上下翻
  // 判据必须是「谁更大」而不是「有没有 deltaX」：preventDefault 是整事件级的，
  // 触控板两指斜滑只要带一丁点 deltaX，纵向分量就会被整个吞掉 → 想往下翻却横着走。
  $('board').addEventListener('wheel', (e) => {
    const k = e.deltaMode === 1 ? 16 : 1;                 // 行模式的滚轮换算成像素，否则一格只挪 1px
    const rawX = (e.deltaX || 0) * k;
    const rawY = (e.deltaY || 0) * k;
    const shiftX = e.shiftKey && !e.ctrlKey && !e.metaKey;  // Shift+滚轮：部分浏览器只给 deltaY
    const dx = shiftX && !rawX ? rawY : rawX;
    if (dx && (shiftX || Math.abs(dx) > Math.abs(rawY) * 1.2)) {
      const moved = panByPx(dx);
      // Shift+滚轮是明确的「要横向」，撞到两端也吞掉；
      // 斜向手势撞到两端就放行，让纵向分量接着滚
      if (moved || shiftX) { e.preventDefault(); return; }
    }
    if (!(e.ctrlKey || e.metaKey)) return;
    e.preventDefault();
    const r = $('tl-canvas').getBoundingClientRect();
    const p = (e.clientX - r.left - LABEL_W) / Math.max(1, r.width - LABEL_W);
    zoomAt(p, e.deltaY > 0 ? 1.18 : 0.85);
  }, { passive: false });

  track.addEventListener('dblclick', () => {
    const s = SRC();
    setWin(s._lo, s._hi);
  });
}

/* ---------------------------------------------------------- 主区拖拽平移 */
/* 按住主区拖 = 像拖地图一样操作：
   左右拖 → 平移时间轴；上下拖 → 滚泳道（放大成卡片后一屏放不下，得能上下翻）。
   关键是要和单击区分开：位移不足 4px 一律当点击，卡片 / 柱条 / 泳道标签照常工作；
   轴一旦定下就锁住，免得手抖的横向抖动把纵向滚动带成平移。
   真拖起来之后，把鼠标松开时浏览器补发的那一发 click 吃掉，免得误开链接或误选。 */
let panDrag = null;
let panAte = false;

function setupPan() {
  const board = $('board');

  board.addEventListener('mousedown', (e) => {
    panAte = false;                                    // 新的一次按下开始，上一次的抑制标记作废
    if (e.button !== 0) return;
    if (e.target.closest('a, button, input')) return;   // 这些元素左键有自己的事要办
    panDrag = { x: e.clientX, y: e.clientY, t0: S.t0, w: S.t1 - S.t0,
                scroll0: board.scrollTop, axis: null };
  });

  window.addEventListener('mousemove', (e) => {
    if (!panDrag) return;
    const dx = e.clientX - panDrag.x;
    const dy = e.clientY - panDrag.y;
    if (!panDrag.axis) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 4) return;   // 4px 以内算点击，不动视野
      panDrag.axis = Math.abs(dx) >= Math.abs(dy) ? 'x' : 'y';
      document.body.classList.add('panning');
    }
    e.preventDefault();
    if (panDrag.axis === 'y') {
      board.scrollTop = panDrag.scroll0 - dy;        // 往上拖 → 内容往上走 → 看到下面的泳道
      return;
    }
    const s = SRC(), w = panDrag.w;
    // 跟手：往左拖 → 内容跟着往左走 → 看到更晚的时间
    const t0 = Math.max(s._lo, Math.min(panDrag.t0 - dx / Math.max(1, trackW()) * w, s._hi - w));
    S.t0 = t0; S.t1 = t0 + w;
    renderRuler(); renderLanes(); renderOverview();
  });

  window.addEventListener('mouseup', () => {
    if (!panDrag) return;
    const axis = panDrag.axis;
    panDrag = null;
    document.body.classList.remove('panning');
    if (!axis) return;
    panAte = true;                                     // 拖完这一发 click 要拦掉，350ms 兜底自清
    setTimeout(() => { panAte = false; }, 350);
  });

  // 捕获阶段拦，别让它落到卡片 / 柱条上
  window.addEventListener('click', (e) => {
    if (!panAte) return;
    panAte = false;
    e.stopPropagation();
    e.preventDefault();
  }, true);
}

function setWin(a, b) {
  const s = SRC(), span = s._hi - s._lo;
  let w = Math.min(span, Math.max(MIN_WIN, b - a));
  // a 是「绝对时间戳」，必须先减掉 _lo 换成偏移量再夹取 ——
  // 直接拿绝对值和 [0, span-w] 比，永远会取到 span-w，把视野甩到最右端
  // （点全览条跳转、⌘滚轮缩放、抽屉里的月份跳转，全都是这么被带歪的）
  let x = Math.min(Math.max(0, a - s._lo), span - w);
  S.t0 = s._lo + x;
  S.t1 = s._lo + x + w;
  renderRuler(); renderLanes(); renderOverview();
}

/* 以 p（0~1 的位置）为锚点缩放 k 倍 */
function zoomAt(p, k) {
  const s = SRC(), span = s._hi - s._lo;
  const center = s._lo + Math.min(1, Math.max(0, p)) * span;
  const w = Math.min(span, Math.max(MIN_WIN, (S.t1 - S.t0) * k));
  const ratio = (center - S.t0) / ((S.t1 - S.t0) || 1);
  setWin(center - w * ratio, center + w * (1 - ratio));
}

/* 把水平方向的像素位移换算成时间位移。
   视野宽永远铺满 trackW() 像素（见 X()），所以 dx 像素 ≈ dx/trackW() 个视野宽。
   返回是否真的动了 —— 已经贴到两端就没动，调用方不用白重排一遍。 */
function panByPx(dx) {
  const s = SRC();
  const w = S.t1 - S.t0;
  const t0 = Math.max(s._lo, Math.min(S.t0 + dx / Math.max(1, trackW()) * w, s._hi - w));
  if (t0 === S.t0) return false;
  S.t0 = t0; S.t1 = t0 + w;
  renderRuler(); renderLanes(); renderOverview();
  return true;
}

/* ---------------------------------------------------------- 主流程 */

function setSource(i) {
  S.si = i;
  const s = DATA.sources[i];
  S.f0 = s._lo; S.f1 = s._hi;
  S.lane = null; S.sel = null;
  // focus = 只看数据密集的主线区间，否则铺满全部时间跨度
  if (S.focus) {
    S.t0 = Math.max(s._lo, s._p5 - 14 * 86400000);
    S.t1 = Math.min(s._hi, s._p95 + 21 * 86400000);
  } else {
    S.t0 = s._lo;
    S.t1 = s._hi;
  }
  renderAll();
}

/* 让所有泳道尽量在一屏内放下，放不下则自然滚动 */
function fitLaneHeight() {
  const n = SRC().lanes.length;
  if (!n) return;
  const avail = $('board').clientHeight - 34;   // 减去刻度尺
  const h = Math.max(54, Math.min(88, Math.floor(avail / n)));
  document.documentElement.style.setProperty('--lane-h', h + 'px');
}

function renderAll() {
  fitLaneHeight();
  renderTopbar();
  renderRuler();
  renderLanes();
  renderOverview();
  renderDrawer();
}

function boot() {
  if (!DATA || !DATA.sources || !DATA.sources.length) {
    document.body.innerHTML = '<div class="empty">没有找到时间线数据</div>';
    return;
  }
  prep();

  $('q').addEventListener('input', (e) => {
    S.q = e.target.value.trim().toLowerCase();
    $('q-clear').style.display = S.q ? '' : 'none';
    renderLanes();
  });
  $('q-clear').onclick = () => {
    $('q').value = ''; S.q = ''; $('q-clear').style.display = 'none'; renderLanes(); $('q').focus();
  };

  // tooltip 里的条目是可点的，鼠标移进去时先别收
  TIP.onmouseenter = keepTip;
  TIP.onmouseleave = hideTip;

  $('z-in').onclick = () => zoomAt(0.5, 0.62);
  $('z-out').onclick = () => zoomAt(0.5, 1.6);

  $('tg-events').onclick = (e) => {
    S.showEv = !S.showEv;
    e.currentTarget.classList.toggle('on', S.showEv);
    renderLanes();
  };
  $('tg-focus').onclick = (e) => {
    S.focus = !S.focus;
    e.currentTarget.classList.toggle('on', S.focus);
    const s = SRC();
    if (S.focus) setWin(s._p5 - 14 * 86400000, s._p95 + 21 * 86400000);
    else setWin(s._lo, s._hi);
  };

  // 点击空白关闭抽屉
  $('board').addEventListener('click', () => {
    if (S.sel) { S.sel = null; renderLanes(); renderDrawer(); }
  });

  // 默认选数据量更大的源
  let best = 0;
  DATA.sources.forEach((s, i) => { if (s.total > DATA.sources[best].total) best = i; });
  setSource(best);

  setupOverview();
  setupPan();

  let rt;
  window.addEventListener('resize', () => {
    clearTimeout(rt);
    rt = setTimeout(() => {
      fitLaneHeight(); renderRuler(); renderLanes(); renderOverview();
    }, 120);
  });
}

boot();
})();

