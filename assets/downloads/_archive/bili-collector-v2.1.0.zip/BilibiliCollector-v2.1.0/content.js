/**
 * B站 Collector — Content Script v4 (Passive Mode)
 * 只负责“接住” B 站官方发出的数据，保证 100% 正确且不触发风控。
 */
(function () {
  'use strict';
  if (!location.hostname.includes('bilibili.com')) return;

  // ===== 1. 注入悬浮按钮 =====
  function injectLauncher() {
    if (document.getElementById('bhc-launcher')) return;
    const style = document.createElement('style');
    style.textContent = `
      #bhc-launcher {
        position: fixed; right: -140px; top: 50%; transform: translateY(-50%); z-index: 2147483647;
        background: #7b6ff0; color: white; padding: 10px 18px; border-radius: 28px 0 0 28px;
        cursor: pointer; font-family: 'PingFang SC', sans-serif; box-shadow: -4px 0 20px rgba(0,0,0,.2);
        transition: right .35s; display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600;
      }
      #bhc-launcher:hover { right: 0; background: #fb7299; }
    `;
    document.head.appendChild(style);
    const el = document.createElement('div');
    el.id = 'bhc-launcher';
    el.innerHTML = `<span>📂</span><span>Collector</span>`;
    el.onclick = () => chrome.runtime.sendMessage({ action: 'open_dashboard' });
    document.body.appendChild(el);
  }

  // ===== 2. 核心：全被动数据拦截 (XMLHttpRequest + fetch) =====
  function patchXHR() {
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, url) { this._url = url; return origOpen.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function() {
      this.addEventListener('load', () => {
        if (isBiliApi(this._url)) {
          try { handleBiliData(this._url, JSON.parse(this.responseText)); } catch(e){}
        }
      });
      return origSend.apply(this, arguments);
    };
  }

  function patchFetch() {
    const origFetch = window.fetch;
    window.fetch = function(input) {
      const url = typeof input === 'string' ? input : (input?.url || '');
      return origFetch.apply(this, arguments).then(res => {
        if (isBiliApi(url)) {
          res.clone().json().then(data => handleBiliData(url, data)).catch(()=>{});
        }
        return res;
      });
    };
  }

  function isBiliApi(url) {
    return url.includes('/history/cursor') || url.includes('/resource/list') || url.includes('/history/toview');
  }

  function handleBiliData(url, json) {
    if (!json || json.code !== 0) return;
    let items = [];
    let source = '';

    if (url.includes('/history/cursor')) { items = json.data?.list || []; source = 'history'; }
    else if (url.includes('/resource/list')) { items = json.data?.medias || []; source = 'favorites'; }
    else if (url.includes('/history/toview')) { items = json.data?.list || []; source = 'toview'; }

    if (items.length > 0) {
      // 存储到本地持久化缓存
      chrome.storage.local.get(['bhc_cache'], (res) => {
        const cache = res.bhc_cache || { history: [], favorites: [], toview: [] };
        if (!cache.toview) cache.toview = [];
        
        // 合并数据并去重
        const newItems = items.filter(item => {
          const id = item.bvid || item.aid || item.history?.bvid;
          return id && !cache[source].some(cached => (cached.bvid || cached.aid || cached.history?.bvid) === id);
        });

        if (newItems.length > 0) {
          cache[source] = [...newItems, ...cache[source]].slice(0, 5000); // 仅保留最近5000条
          chrome.storage.local.set({ bhc_cache: cache }, () => {
            chrome.runtime.sendMessage({ action: 'cache_updated', source });
          });
        }
      });
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'proxy_fetch') {
      fetch(msg.url)
        .then(res => res.json())
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true; // keep channel open
    }
  });

  patchXHR();
  patchFetch();
  setTimeout(injectLauncher, 1000);
})();
