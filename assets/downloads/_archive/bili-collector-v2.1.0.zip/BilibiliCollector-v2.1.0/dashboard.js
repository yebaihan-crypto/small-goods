/**
 * B站 Collector — Dashboard Logic v5
 * Fetches via content script proxy. Renders three-column layout.
 */
(function () {
  'use strict';

  // ==================== CATEGORIES ====================
  const CATS = [
    { id: 'movie',     name: '影视',  icon: '🎬', color: '#e05252', tids: [181,182,183,85,177,180,124], keywords: ['电影','影评','影视','纪录片','短片','剧集','电视剧','院线','预告片','影解说'] },
    { id: 'anime',     name: '动画',  icon: '🎌', color: '#e07843', tids: [1,24,25,47,210,86,253,167,168,169],  keywords: ['动漫','动画','番剧','二次元','MAD','新番','漫画','声优'] },
    { id: 'design',    name: '设计',  icon: '✏️', color: '#7b6ff0', tids: [32],  keywords: ['设计','UI','UX','Figma','Photoshop','Blender','C4D','AE','插画','视觉','平面','版式','品牌','海报','LOGO'] },
    { id: 'tech',      name: '科技',  icon: '💻', color: '#3896d4', tids: [188,95,230,231,232,233], keywords: ['科技','数码','手机','电脑','AI','编程','代码','开发','评测','芯片','GPU','开源','深度学习','大模型','DeepSeek','Claude','Gemini','ChatGPT'] },
    { id: 'music',     name: '音乐',  icon: '🎵', color: '#c99b26', tids: [3,28,29,30,31,59,193,243,244], keywords: ['音乐','歌曲','翻唱','MV','演唱会','乐器','钢琴','吉他','说唱','电子音乐','纯音乐'] },
    { id: 'game',      name: '游戏',  icon: '🎮', color: '#3daa5e', tids: [4,17,171,172,173,121,136,19], keywords: ['游戏','攻略','实况','手游','端游','Steam','原神','崩坏','电竞','FPS','RPG','我的世界'] },
    { id: 'food',      name: '美食',  icon: '🍜', color: '#d45252', tids: [211,76,212,213,214,215], keywords: ['美食','做菜','烹饪','探店','吃播','食谱','蛋糕','烘焙','火锅','日料'] },
    { id: 'knowledge', name: '知识',  icon: '📚', color: '#3896d4', tids: [36,201,228,207,208,209,229], keywords: ['科普','知识','学习','历史','哲学','物理','数学','公开课','TED','书评','考研'] },
    { id: 'life',      name: '生活',  icon: '🏠', color: '#33a060', tids: [160,138,254,250,251,239,161,162,21], keywords: ['生活','日常','vlog','装修','家居','宠物','猫','狗','租房','习惯','效率'] },
    { id: 'sports',    name: '运动',  icon: '⚽', color: '#b5960e', tids: [234,235,249,164,236,237,238], keywords: ['运动','健身','篮球','足球','NBA','跑步','瑜伽','减肥','骑行','马拉松'] },
    { id: 'fashion',   name: '时尚',  icon: '👗', color: '#c94d99', tids: [155,157,158,159,252], keywords: ['时尚','穿搭','护肤','美妆','化妆','口红','香水','球鞋','潮牌'] },
    { id: 'travel',    name: '旅行',  icon: '✈️', color: '#2896ac', tids: [],    keywords: ['旅行','旅游','自驾','景点','出行','签证','露营','穷游','背包'] },
    { id: 'car',       name: '汽车',  icon: '🚗', color: '#4c72c4', tids: [223,176,224,225,240], keywords: ['汽车','新车','试驾','电动车','新能源','特斯拉','比亚迪','F1','改装'] },
    { id: 'finance',   name: '财经',  icon: '📈', color: '#3ea052', tids: [],    keywords: ['财经','股票','基金','理财','投资','比特币','创业','副业','被动收入'] },
  ];

  // ==================== STATE ====================
  const S = {
    mid: null,
    source: 'history',   // history | favorites | toview
    cat: 'all',
    folder: null,
    folders: [],
    q: '',
    raw: { history: [], favorites: {}, toview: [] },
    classified: {},      // catId -> [item]
    selected: null,      // currently selected item
    loading: false,
  };

  // ==================== CLASSIFY ====================
  function classify(item) {
    const text = ((item.title || '') + ' ' + (item.tag_name || '') + ' ' + (item.tname || '')).toLowerCase();
    const tid = item.tid || 0;
    const hits = [];
    for (const cat of CATS) {
      if (cat.tids.includes(tid) || cat.keywords.some(k => text.includes(k.toLowerCase()))) {
        hits.push(cat.id);
      }
    }
    return hits;
  }

  function rebuildClassified() {
    const result = {};
    CATS.forEach(c => result[c.id] = []);
    listBySource().forEach(item => {
      (item._cats || []).forEach(cid => { if (result[cid]) result[cid].push(item); });
    });
    S.classified = result;
  }

  // ==================== HELPERS ====================
  function listBySource() {
    if (S.source === 'history')   return S.raw.history;
    if (S.source === 'favorites') return S.raw.favorites[S.folder] || [];
    if (S.source === 'toview')    return S.raw.toview;
    return [];
  }

  function filteredList() {
    let list = S.cat === 'all' ? listBySource() : (S.classified[S.cat] || []);
    if (S.q) list = list.filter(v => (v._title || '').toLowerCase().includes(S.q) || (v._author || '').toLowerCase().includes(S.q));
    return list;
  }

  function normalize(item) {
    item._title  = item.title || '无标题';
    item._author = item.author_name || item.owner?.name || item.upper?.name || '';
    item._pic    = (item.pic || item.cover || '').replace(/^\/\//, 'https://');
    item._bvid   = item.bvid || item.history?.bvid || '';
    item._aid    = item.aid  || item.history?.oid  || '';
    item._dur    = item.duration || 0;
    item._ts     = item.view_at  || item.ctime || item.fav_time || item.pubdate || 0;
    item._cats   = classify(item);
    return item;
  }

  function fmtDur(sec) {
    if (!sec) return '';
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return h ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${m}:${String(s).padStart(2,'0')}`;
  }

  function fmtTime(ts) {
    if (!ts) return '';
    const d = new Date(ts * 1000), now = new Date(), diff = (now - d) / 1000;
    if (diff < 60)   return '刚刚';
    if (diff < 3600) return `${Math.floor(diff/60)}分钟前`;
    if (diff < 86400)return `${Math.floor(diff/3600)}小时前`;
    if (diff < 86400 * 30) return `${Math.floor(diff/86400)}天前`;
    return `${d.getFullYear()}/${d.getMonth()+1}/${d.getDate()}`;
  }

  // ==================== PROXY FETCH ====================
  async function proxyFetch(url) {
    // 1. 优先尝试在 Extension 上下文直接 fetch
    try {
      const response = await fetch(url, { credentials: 'include' });
      if (response.ok) {
        const json = await response.json();
        if (url.includes('/web-interface/nav')) {
          if (json.code === 0 && json.data?.isLogin) {
            S._directFetchWorks = true; // 标记直接请求可用
            return json;
          }
        } else if (S._directFetchWorks) {
          // 如果 nav 验证通过，后续请求直接走直接请求，提高流畅度
          return json;
        }
      }
    } catch (e) {
      console.warn('[BHC] Direct fetch failed, falling back to tab proxy:', e);
    }

    // 2. 备用方案：路由到活跃的 B 站标签页发送请求（免去三方 Cookie 限制）
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: 'proxy_fetch_request', url }, res => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (res?.success) return resolve(res.data);
        reject(new Error(res?.error || '代理请求失败'));
      });
    });
  }

  // ==================== DATA SYNC LOGIC ====================
  async function syncData() {
    showStatus('正在同步 B 站数据...', 'loading');
    try {
      // 1. 读取本地缓存
      const resLocal = await chrome.storage.local.get(['bhc_cache', 'bhc_folders', 'bhc_fav_by_folder']);
      let cache = resLocal.bhc_cache || { history: [], favorites: [], toview: [] };
      if (!cache.toview) cache.toview = []; // 兼容旧缓存
      let folderCache = resLocal.bhc_folders || [];
      let favByFolder = resLocal.bhc_fav_by_folder || {};

      // 2. 根据当前 Source 进行 API 抓取
      if (S.source === 'history') {
        let historyList = [];
        let max = 0, view_at = 0, business = '';
        // 循环拉取 60 页 (1200条记录)
        for (let page = 0; page < 60; page++) {
          let url = `https://api.bilibili.com/x/web-interface/history/cursor?ps=20`;
          if (page > 0 && max) {
            url += `&max=${max}&view_at=${view_at}&business=${business}`;
          }
          const res = await proxyFetch(url);
          if (res.code === 0 && res.data?.list?.length) {
            historyList.push(...res.data.list);
            const cursor = res.data.cursor;
            max = cursor.max;
            view_at = cursor.view_at;
            business = cursor.business;
          } else {
            break;
          }
          await new Promise(r => setTimeout(r, 120));
        }

        if (historyList.length > 0) {
          const existing = new Set(cache.history.map(v => v.bvid || v.aid || v.history?.bvid));
          const newItems = historyList.filter(v => {
            const id = v.bvid || v.aid || v.history?.bvid;
            return id && !existing.has(id);
          });
          cache.history = [...newItems, ...cache.history].slice(0, 5000); // 缓存上限提升至 5000 条
          await chrome.storage.local.set({ bhc_cache: cache });
        }
      } 
      else if (S.source === 'favorites') {
        // 抓取收藏夹目录列表
        const fRes = await proxyFetch(`https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=${S.mid}`);
        if (fRes.code === 0 && fRes.data) {
          const list = Array.isArray(fRes.data) ? fRes.data : (fRes.data.list || []);
          folderCache = list.map(f => ({ id: f.id, title: f.title, count: f.media_count }));
          await chrome.storage.local.set({ bhc_folders: folderCache });
          S.folders = folderCache;

          // 默认选中第一个收藏夹
          if (!S.folder && S.folders.length > 0) {
            S.folder = S.folders[0].id;
          }

          if (S.folder) {
            let folderFavs = [];
            // 循环拉取 60 页 (1200条记录)
            for (let pn = 1; pn <= 60; pn++) {
              const listRes = await proxyFetch(`https://api.bilibili.com/x/v3/fav/resource/list?media_id=${S.folder}&ps=20&pn=${pn}`);
              if (listRes.code === 0 && listRes.data?.medias?.length) {
                folderFavs.push(...listRes.data.medias);
                if (listRes.data.has_more === false) break; // 接口明确返回没有更多了
              } else {
                break;
              }
              await new Promise(r => setTimeout(r, 120));
            }
            if (folderFavs.length > 0) {
              favByFolder[S.folder] = folderFavs;
              await chrome.storage.local.set({ bhc_fav_by_folder: favByFolder });
            }
          }
        }
      }
      else if (S.source === 'toview') {
        // 抓取“稍后再看”列表
        const res = await proxyFetch('https://api.bilibili.com/x/v2/history/toview');
        if (res.code === 0 && res.data?.list) {
          const fetched = res.data.list;
          const existing = new Set(cache.toview.map(v => v.bvid || v.aid));
          const newItems = fetched.filter(v => {
            const id = v.bvid || v.aid;
            return id && !existing.has(id);
          });
          cache.toview = [...newItems, ...cache.toview].slice(0, 5000);
          await chrome.storage.local.set({ bhc_cache: cache });
        }
      }

      // 3. 将本地缓存加载到内存状态 S 中
      S.raw.history = (cache.history || []).map(normalize);
      S.raw.toview = (cache.toview || []).map(normalize);
      S.folders = folderCache;
      
      // 组装收藏数据到 S.raw.favorites
      S.raw.favorites = {};
      for (const fid in favByFolder) {
        S.raw.favorites[fid] = (favByFolder[fid] || []).map(normalize);
      }
      
      // 容错：如果当前收藏夹还没有数据
      if (S.folder && !S.raw.favorites[S.folder]) {
        S.raw.favorites[S.folder] = [];
      }

      if (!S.folder && S.folders.length > 0) {
        S.folder = S.folders[0].id;
      }

      // 4. 重建分类，渲染 UI
      rebuildClassified();
      renderSidebar();
      renderList();
      hideStatus();

      const count = listBySource().length;
      tlDirty = true;
      setSyncStatus(`已从 B 站同步 ${count} 条视频`);
    } catch (e) {
      console.error(e);
      showStatus('同步失败：' + e.message + '<br><small>请确保浏览器中有打开的 B 站标签页（已登录），然后点击下方按钮重试</small>', 'error');
    }
  }

  // ==================== RENDER SIDEBAR ====================
  function renderSidebar() {
    const list = listBySource();
    $('count-all').textContent = list.length;

    const nav = $('category-list');
    nav.innerHTML = '';
    CATS.forEach(cat => {
      const count = (S.classified[cat.id] || []).length;
      const el = document.createElement('div');
      el.className = 'cat-item' + (S.cat === cat.id ? ' active' : '');
      el.innerHTML = `
        <span class="cat-item-label">
          <span class="cat-dot" style="background:${cat.color}"></span>
          <span class="cat-name">${cat.name}</span>
        </span>
        <span class="cat-count">${count}</span>`;
      el.addEventListener('click', () => { 
        S.cat = cat.id; 
        $('cat-all').classList.remove('active'); 
        renderSidebar(); 
        renderList(); 
      });
      nav.appendChild(el);
    });

    // 全部高亮
    $('cat-all').classList.toggle('active', S.cat === 'all');

    // 来源按钮高亮
    document.querySelectorAll('.src-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.source === S.source);
    });

    // 渲染收藏夹 Tab 栏
    const ft = $('folder-tabs');
    if (S.source === 'favorites' && S.folders.length > 0) {
      ft.classList.remove('hidden');
      ft.innerHTML = '';
      S.folders.forEach(f => {
        const t = document.createElement('div');
        t.className = 'folder-tab' + (S.folder === f.id ? ' active' : '');
        t.textContent = f.title;
        t.addEventListener('click', async () => { 
          S.folder = f.id; 
          const hasCache = S.raw.favorites[S.folder] && S.raw.favorites[S.folder].length > 0;
          if (!hasCache) {
            await syncData();
          } else {
            rebuildClassified();
            renderSidebar();
            renderList();
            setSyncStatus(`已切换至收藏夹：${f.title} (缓存共 ${S.raw.favorites[S.folder].length} 条)`);
          }
        });
        ft.appendChild(t);
      });
    } else {
      ft.classList.add('hidden');
    }
  }

  // ==================== RENDER LIST ====================
  function renderList() {
    const list = filteredList();
    const container = $('video-list');
    container.innerHTML = '';

    if (!list.length) {
      container.innerHTML = `<div class="list-placeholder"><span class="pl-icon">📭</span>暂无相关内容</div>`;
      return;
    }

    list.forEach((item, i) => {
      const card = document.createElement('div');
      card.className = 'v-card' + (S.selected === item ? ' selected' : '');
      card.style.animationDelay = `${Math.min(i * 25, 400)}ms`;

      const catBadges = (item._cats || []).slice(0, 2).map(cid => {
        const cat = CATS.find(c => c.id === cid);
        return cat ? `<span class="v-badge badge-${cat.id}">${cat.name}</span>` : '';
      }).join('');

      card.innerHTML = `
        <img class="v-thumb" src="${item._pic}" loading="lazy" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22110%22 height=%2262%22><rect fill=%22%23f0f0f0%22 width=%22110%22 height=%2262%22/></svg>'">
        <div class="v-info">
          <div class="v-title">${item._title}</div>
          <div class="v-meta">
            ${item._author ? `<span class="v-author">@${item._author}</span>` : ''}
            <span class="v-time">${fmtTime(item._ts)}</span>
            ${catBadges}
          </div>
        </div>`;

      card.addEventListener('click', () => { 
        S.selected = item; 
        renderList(); 
        renderDetail(item); 
      });
      container.appendChild(card);
    });
  }

  // ==================== RENDER DETAIL ====================
  function renderDetail(item) {
    $('detail-empty').classList.add('hidden');
    const dc = $('detail-content');
    dc.classList.remove('hidden');

    $('detail-cover').src = item._pic;
    $('detail-duration').textContent = fmtDur(item._dur);
    $('detail-title').textContent = item._title;
    $('detail-author').innerHTML = item._author ? `<span>👤</span><span>${item._author}</span>` : '';
    $('detail-meta').innerHTML = item._ts ? `<span>🕐 ${fmtTime(item._ts)}</span>` : '';

    // 分区徽章
    $('detail-cats').innerHTML = (item._cats || []).map(cid => {
      const cat = CATS.find(c => c.id === cid);
      return cat ? `<span class="v-badge badge-${cat.id}" style="font-size:12px;padding:3px 10px;">${cat.icon} ${cat.name}</span>` : '';
    }).join('');

    // 播放按钮
    const btn = $('detail-open-btn');
    btn.href = item._bvid ? `https://www.bilibili.com/video/${item._bvid}` : (item._aid ? `https://www.bilibili.com/video/av${item._aid}` : '#');
  }

  // ==================== STATUS OVERLAYS ====================
  function showStatus(msg, type) {
    const ov = $('status-overlay');
    ov.classList.remove('hidden');
    $('status-spinner').classList.toggle('hidden', type !== 'loading');
    $('status-msg').innerHTML = msg;
    $('status-retry').classList.toggle('hidden', type !== 'error');
  }

  function hideStatus() {
    $('status-overlay').classList.add('hidden');
  }

  function setSyncStatus(msg) {
    $('sync-status').textContent = msg;
  }

  // ==================== VIEW TABS（资料库 / 时间线） ====================

  const TL_SRC = 'timeline/index.html?embed=1';
  let tlLoaded = false;   // 首次切过去才加载，不拖慢打开仪表盘
  let tlDirty = false;    // 数据动过 → 下次切过去自动重算

  function initViewTabs() {
    const wrap = $('timeline-view');
    const frame = $('tl-frame');
    const tabs = document.querySelectorAll('.view-tab');

    function load() {
      tlLoaded = true;
      tlDirty = false;
      // 换 URL 而不是 reload() —— 时间线页每次加载都重读 chrome.storage 现算
      frame.src = TL_SRC + '&t=' + Date.now();
      $('tl-bar-sub').textContent =
        'B站历史记录 · 重新生成于 ' + new Date().toLocaleTimeString();
    }

    function show(name) {
      const isTimeline = name === 'timeline';
      document.body.classList.toggle('view-timeline', isTimeline);
      wrap.classList.toggle('hidden', !isTimeline);
      tabs.forEach(b => b.classList.toggle('active', b.dataset.view === name));
      if (isTimeline && (!tlLoaded || tlDirty)) load();
    }

    tabs.forEach(b => b.addEventListener('click', () => show(b.dataset.view)));
    $('tl-reload').addEventListener('click', () => {
      if (wrap.classList.contains('hidden')) return;
      load();
    });
  }

  // ==================== $ SHORTCUT ====================
  function $(id) { return document.getElementById(id); }

  // ==================== EXPORT LOGIC ====================
  let selectedExportFormat = 'json';

  function initExportModal() {
    const trigger = $('export-trigger-btn');
    const modal = $('export-modal');
    const cancelBtn = $('export-cancel-btn');
    const confirmBtn = $('export-confirm-btn');
    const cards = document.querySelectorAll('.export-opt-card');
    const importBtn = $('export-import-btn');
    const importFileInput = $('export-import-file');

    if (!trigger || !modal) return;

    trigger.addEventListener('click', () => {
      // Reset default selection to JSON
      selectedExportFormat = 'json';
      cards.forEach(c => {
        c.classList.toggle('active', c.dataset.format === 'json');
      });
      modal.classList.remove('hidden');
    });

    cancelBtn.addEventListener('click', () => {
      modal.classList.add('hidden');
    });

    // Close when clicking overlay (except the card itself)
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });

    cards.forEach(card => {
      card.addEventListener('click', () => {
        cards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        selectedExportFormat = card.dataset.format;
      });
    });

    confirmBtn.addEventListener('click', async () => {
      modal.classList.add('hidden');
      await executeExport(selectedExportFormat);
    });

    if (importBtn && importFileInput) {
      importBtn.addEventListener('click', () => {
        importFileInput.click();
      });

      importFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          modal.classList.add('hidden');
          handleImportJson(file);
          // 清空 value 允许重复选同一个文件
          importFileInput.value = '';
        }
      });
    }
  }

  async function handleImportJson(file) {
    if (!file) return;
    showStatus('正在读取并校验备份文件...', 'loading');
    
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const imported = JSON.parse(e.target.result);
        
        // 校验基本数据结构
        if (!imported.history && !imported.favorites_by_folder && !imported.toview) {
          throw new Error('备份文件格式不匹配，未包含有效的 B站 Collector 数据');
        }

        // 读取当前本地缓存
        const resLocal = await chrome.storage.local.get(['bhc_cache', 'bhc_folders', 'bhc_fav_by_folder']);
        let cache = resLocal.bhc_cache || { history: [], favorites: [], toview: [] };
        if (!cache.toview) cache.toview = [];
        let folders = resLocal.bhc_folders || [];
        let favByFolder = resLocal.bhc_fav_by_folder || {};

        // 1. 合并 & 去重 history
        const mergedHistory = [...(imported.history || []), ...(cache.history || [])];
        const historyMap = new Map();
        mergedHistory.forEach(item => {
          const id = item.bvid || item.aid || item.history?.bvid;
          if (id && !historyMap.has(id)) {
            historyMap.set(id, item);
          }
        });
        cache.history = Array.from(historyMap.values()).slice(0, 5000);



        // 3. 合并 & 去重 toview
        const mergedToview = [...(imported.toview || []), ...(cache.toview || [])];
        const toviewMap = new Map();
        mergedToview.forEach(item => {
          const id = item.bvid || item.aid;
          if (id && !toviewMap.has(id)) {
            toviewMap.set(id, item);
          }
        });
        cache.toview = Array.from(toviewMap.values()).slice(0, 5000);

        // 4. 合并 folders
        const importedFolders = imported.folders || [];
        importedFolders.forEach(inf => {
          if (!folders.some(f => f.id === inf.id)) {
            folders.push(inf);
          }
        });

        // 5. 合并 & 去重 favorites_by_folder
        const importedFavs = imported.favorites_by_folder || {};
        for (const fid in importedFavs) {
          const mergedFolderFavs = [...(importedFavs[fid] || []), ...(favByFolder[fid] || [])];
          const favMap = new Map();
          mergedFolderFavs.forEach(item => {
            const id = item.bvid || item.aid || item.history?.bvid;
            if (id && !favMap.has(id)) {
              favMap.set(id, item);
            }
          });
          favByFolder[fid] = Array.from(favMap.values());
        }

        // 写入本地持久化缓存
        await chrome.storage.local.set({
          bhc_cache: cache,
          bhc_folders: folders,
          bhc_fav_by_folder: favByFolder
        });

        hideStatus();
        showStatus('🎉 备份数据导入并合并成功！', 'success');
        setTimeout(hideStatus, 1500);

        // 更新当前运行态 S
        S.raw.history = (cache.history || []).map(normalize);
        S.raw.toview = (cache.toview || []).map(normalize);
        S.folders = folders;
        S.raw.favorites = {};
        for (const fid in favByFolder) {
          S.raw.favorites[fid] = (favByFolder[fid] || []).map(normalize);
        }

        rebuildClassified();
        renderSidebar();
        renderList();
        tlDirty = true;
        setSyncStatus(`成功导入并合并备份数据`);

      } catch (err) {
        console.error(err);
        showStatus('解析/导入文件失败：<br><small>' + err.message + '</small>', 'error');
      }
    };
    reader.onerror = () => {
      showStatus('读取文件失败', 'error');
    };
    reader.readAsText(file);
  }

  async function executeExport(format) {
    showStatus('正在准备导出数据...', 'loading');
    try {
      // 1. 从 local storage 中读取完整数据
      const resLocal = await chrome.storage.local.get(['bhc_cache', 'bhc_folders', 'bhc_fav_by_folder']);
      const cache = resLocal.bhc_cache || { history: [], favorites: [], toview: [] };
      const folders = resLocal.bhc_folders || [];
      const favByFolder = resLocal.bhc_fav_by_folder || {};

      const exportDataObj = {
        version: "1.0",
        exported_at: new Date().toISOString(),
        history: cache.history || [],
        toview: cache.toview || [],
        folders: folders,
        favorites_by_folder: favByFolder
      };

      let content = '';
      let filename = '';
      let mimeType = '';

      const dateStr = new Date().toISOString().split('T')[0];

      if (format === 'json') {
        content = JSON.stringify(exportDataObj, null, 2);
        filename = `bilibili_collector_export_${dateStr}.json`;
        mimeType = 'application/json;charset=utf-8;';
      } 
      else if (format === 'html') {
        content = generateHtmlBookmarks(exportDataObj);
        filename = `bilibili_collector_bookmarks_${dateStr}.html`;
        mimeType = 'text/html;charset=utf-8;';
      } 
      else if (format === 'csv') {
        content = generateCsv(exportDataObj);
        filename = `bilibili_collector_data_${dateStr}.csv`;
        mimeType = 'text/csv;charset=utf-8;';
      }

      // 2. 触发下载
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      hideStatus();
      setSyncStatus(`数据已导出为 ${format.toUpperCase()} 格式`);
    } catch (e) {
      console.error(e);
      showStatus('导出失败：' + e.message, 'error');
    }
  }

  function generateHtmlBookmarks(data) {
    let html = `<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file.
     It will be read and written by auto-generated codes.
     Do Not Edit! -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>B站 Collector 导出书签</TITLE>
<H1>B站 Collector 导出书签</H1>
<DL><p>
    <DT><H3 ADD_DATE="${Math.floor(Date.now()/1000)}" LAST_MODIFIED="${Math.floor(Date.now()/1000)}">B站 Collector 导出</H3>
    <DL><p>
`;

    const esc = (str) => {
      if (!str) return '';
      return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    };

    // 历史记录
    const history = data.history || [];
    if (history.length > 0) {
      html += `        <DT><H3>历史记录</H3>\n        <DL><p>\n`;
      history.forEach(item => {
        const bvid = item.bvid || item.history?.bvid;
        const url = bvid ? `https://www.bilibili.com/video/${bvid}` : (item.aid ? `https://www.bilibili.com/video/av${item.aid}` : '');
        if (url) {
          const title = item.title || '无标题';
          const author = item.author_name || item.owner?.name || item.upper?.name || '';
          const authorStr = author ? ` [UP: ${author}]` : '';
          const date = item.view_at || item.ctime || Math.floor(Date.now()/1000);
          html += `            <DT><A HREF="${url}" ADD_DATE="${date}">${esc(title) + esc(authorStr)}</A>\n`;
        }
      });
      html += `        </DL><p>\n`;
    }



    // 稍后再看
    const toview = data.toview || [];
    if (toview.length > 0) {
      html += `        <DT><H3>稍后再看</H3>\n        <DL><p>\n`;
      toview.forEach(item => {
        const bvid = item.bvid;
        const url = bvid ? `https://www.bilibili.com/video/${bvid}` : (item.aid ? `https://www.bilibili.com/video/av${item.aid}` : '');
        if (url) {
          const title = item.title || '无标题';
          const author = item.author_name || item.owner?.name || item.upper?.name || '';
          const authorStr = author ? ` [UP: ${author}]` : '';
          const date = item.ctime || Math.floor(Date.now()/1000);
          html += `            <DT><A HREF="${url}" ADD_DATE="${date}">${esc(title) + esc(authorStr)}</A>\n`;
        }
      });
      html += `        </DL><p>\n`;
    }

    // 收藏夹
    const folders = data.folders || [];
    const favByFolder = data.favorites_by_folder || {};
    if (folders.length > 0) {
      html += `        <DT><H3>我的收藏</H3>\n        <DL><p>\n`;
      folders.forEach(f => {
        const items = favByFolder[f.id] || [];
        if (items.length > 0) {
          html += `            <DT><H3>${esc(f.title)}</H3>\n            <DL><p>\n`;
          items.forEach(item => {
            const bvid = item.bvid || item.history?.bvid;
            const url = bvid ? `https://www.bilibili.com/video/${bvid}` : (item.aid ? `https://www.bilibili.com/video/av${item.aid}` : '');
            if (url) {
              const title = item.title || '无标题';
              const author = item.author_name || item.owner?.name || item.upper?.name || '';
              const authorStr = author ? ` [UP: ${author}]` : '';
              const date = item.fav_time || item.ctime || Math.floor(Date.now()/1000);
              html += `                <DT><A HREF="${url}" ADD_DATE="${date}">${esc(title) + esc(authorStr)}</A>\n`;
            }
          });
          html += `            </DL><p>\n`;
        }
      });
      html += `        </DL><p>\n`;
    }

    html += `    </DL><p>\n</DL><p>\n`;
    return html;
  }

  function generateCsv(data) {
    const rows = [
      ['来源', '收藏夹名称', '视频标题', '视频链接', 'UP主', '智能分类', '时长', '关联时间', '封面链接', '封面图预览 (Excel公式)']
    ];

    const csvEsc = (val) => {
      if (val === null || val === undefined) return '';
      const str = String(val);
      if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    };

    const formatDate = (ts) => {
      if (!ts) return '';
      const d = new Date(ts * 1000);
      return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
    };

    const getCatNames = (item) => {
      const normalizedItem = normalize(item);
      const catIds = normalizedItem._cats || [];
      return catIds.map(cid => {
        const c = CATS.find(cat => cat.id === cid);
        return c ? c.name : cid;
      }).join('; ');
    };

    // 1. 历史记录
    const history = data.history || [];
    history.forEach(item => {
      const bvid = item.bvid || item.history?.bvid;
      const url = bvid ? `https://www.bilibili.com/video/${bvid}` : (item.aid ? `https://www.bilibili.com/video/av${item.aid}` : '');
      const title = item.title || '无标题';
      const author = item.author_name || item.owner?.name || item.upper?.name || '';
      const duration = fmtDur(item.duration || 0);
      const date = formatDate(item.view_at || item.ctime);
      const pic = (item.pic || item.cover || '').replace(/^\/\//, 'https://');
      const imgFormula = pic ? `=IMAGE("${pic}")` : '';
      rows.push([
        '历史记录',
        '',
        title,
        url,
        author,
        getCatNames(item),
        duration,
        date,
        pic,
        imgFormula
      ]);
    });



    // 3. 稍后再看
    const toview = data.toview || [];
    toview.forEach(item => {
      const bvid = item.bvid;
      const url = bvid ? `https://www.bilibili.com/video/${bvid}` : (item.aid ? `https://www.bilibili.com/video/av${item.aid}` : '');
      const title = item.title || '无标题';
      const author = item.author_name || item.owner?.name || item.upper?.name || '';
      const duration = fmtDur(item.duration || 0);
      const date = formatDate(item.ctime);
      const pic = (item.pic || item.cover || '').replace(/^\/\//, 'https://');
      const imgFormula = pic ? `=IMAGE("${pic}")` : '';
      rows.push([
        '稍后再看',
        '',
        title,
        url,
        author,
        getCatNames(item),
        duration,
        date,
        pic,
        imgFormula
      ]);
    });

    // 4. 我的收藏
    const folders = data.folders || [];
    const favByFolder = data.favorites_by_folder || {};
    folders.forEach(f => {
      const items = favByFolder[f.id] || [];
      items.forEach(item => {
        const bvid = item.bvid || item.history?.bvid;
        const url = bvid ? `https://www.bilibili.com/video/${bvid}` : (item.aid ? `https://www.bilibili.com/video/av${item.aid}` : '');
        const title = item.title || '无标题';
        const author = item.author_name || item.owner?.name || item.upper?.name || '';
        const duration = fmtDur(item.duration || 0);
        const date = formatDate(item.fav_time || item.ctime);
        const pic = (item.pic || item.cover || '').replace(/^\/\//, 'https://');
        const imgFormula = pic ? `=IMAGE("${pic}")` : '';
        rows.push([
          '我的收藏',
          f.title,
          title,
          url,
          author,
          getCatNames(item),
          duration,
          date,
          pic,
          imgFormula
        ]);
      });
    });

    const csvContent = rows.map(r => r.map(csvEsc).join(',')).join('\n');
    return '\ufeff' + csvContent; // UTF-8 BOM
  }

  // ==================== INITIALIZATION ====================
  async function init() {
    initExportModal();
    initViewTabs();

    // ---- 清空旧的点赞缓存数据 ----
    chrome.storage.local.get(['bhc_cache'], (res) => {
      if (res.bhc_cache && res.bhc_cache.likes) {
        delete res.bhc_cache.likes;
        chrome.storage.local.set({ bhc_cache: res.bhc_cache });
      }
    });

    // ---- Event bindings ----
    document.querySelectorAll('.src-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        S.source = btn.dataset.source;
        S.cat = 'all';
        
        let needSync = false;
        if (S.source === 'history' && (!S.raw.history || S.raw.history.length === 0)) {
          needSync = true;

        } else if (S.source === 'toview' && (!S.raw.toview || S.raw.toview.length === 0)) {
          needSync = true;
        } else if (S.source === 'favorites') {
          if (S.folders.length === 0) {
            needSync = true;
          } else {
            // 自动加载首个收藏夹
            S.folder = S.folders[0].id;
            if (!S.raw.favorites[S.folder] || S.raw.favorites[S.folder].length === 0) {
              needSync = true;
            }
          }
        }

        if (needSync) {
          await syncData();
        } else {
          rebuildClassified();
          renderSidebar();
          renderList();
          
          const count = listBySource().length;
          setSyncStatus(`已切换至${btn.textContent.trim()} (缓存共 ${count} 条)`);
        }
      });
    });

    $('cat-all').addEventListener('click', () => {
      S.cat = 'all';
      renderSidebar();
      renderList();
    });

    $('search-input').addEventListener('input', e => {
      S.q = e.target.value.toLowerCase();
      $('search-clear').classList.toggle('hidden', !S.q);
      renderList();
    });

    $('search-clear').addEventListener('click', () => {
      S.q = '';
      $('search-input').value = '';
      $('search-clear').classList.add('hidden');
      renderList();
    });

    $('sync-btn').addEventListener('click', () => syncData());

    $('status-retry').addEventListener('click', () => {
      hideStatus();
      syncData();
    });

    // ---- 检查 B 站登录状态 ----
    showStatus('正在连线 B 站…', 'loading');
    try {
      const nav = await proxyFetch('https://api.bilibili.com/x/web-interface/nav');
      if (nav.code !== 0 || !nav.data?.isLogin) {
        showStatus('账号未登录<br><small>请先在新标签页中打开并登录 B 站 (bilibili.com)，然后再刷新本页面</small>', 'error');
        return;
      }
      S.mid = nav.data.mid;

      // 在详情栏右上角渲染用户头像和昵称
      const det = $('panel-detail');
      let userEl = $('bhc-user-profile');
      if (!userEl) {
        userEl = document.createElement('div');
        userEl.id = 'bhc-user-profile';
        userEl.style.cssText = 'position:absolute;top:16px;right:20px;display:flex;align-items:center;gap:8px;z-index:10;background:rgba(255,255,255,0.85);backdrop-filter:blur(4px);padding:4px 12px;border-radius:20px;border:2.5px solid #222;box-shadow:0 4px 12px rgba(0,0,0,0.05);';
        document.body.appendChild(userEl);
      }
      userEl.innerHTML = `<img src="${nav.data.face}" style="width:24px;height:24px;border-radius:50%;border:1.5px solid #222;"><span style="font-size:12px;font-weight:700;">${nav.data.uname}</span>`;

      hideStatus();
      await syncData();
    } catch (e) {
      console.error(e);
      showStatus('通信失败：' + e.message + '<br><small>请确保浏览器中有打开的 B 站网页标签页（已登录），然后刷新重试</small>', 'error');
    }

    // ---- 监听来自 content.js 的自动抓取通知 ----
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.action === 'cache_updated') {
        // 当 content_script 嗅探到新的页面滚动加载，直接在后台刷新数据而不需要重新 loading
        chrome.storage.local.get(['bhc_cache', 'bhc_folders', 'bhc_fav_by_folder'], (resLocal) => {
          let cache = resLocal.bhc_cache || { history: [], favorites: [] };
          let folderCache = resLocal.bhc_folders || [];
          let favByFolder = resLocal.bhc_fav_by_folder || {};

          S.raw.history = (cache.history || []).map(normalize);
          S.folders = folderCache;
          
          S.raw.favorites = {};
          for (const fid in favByFolder) {
            S.raw.favorites[fid] = (favByFolder[fid] || []).map(normalize);
          }

          rebuildClassified();
          renderSidebar();
          renderList();
          tlDirty = true;
          setSyncStatus(`已实时同步新数据 · ${new Date().toLocaleTimeString()}`);
        });
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
