/* ==========================================================================
   B站 Collector · 时间线数据构建
   --------------------------------------------------------------------------
   由 ../timeline/build_data.py 的「B站侧」逐函数移植而来，改成在浏览器里现算：

     输入  chrome.storage.local.bhc_cache.history   （插件同步下来的原始 B站 API 条目）
     输出  window.TIMELINE_DATA                     （结构与原 timeline-data.json 一致，
                                                     可直接喂给同一个 app.js）

   与 Python 版的两处差别，都在「中文分词 / 词性」上 —— 浏览器里没有 jieba：

   ① 分词：Intl.Segmenter 的中文词典比 jieba 小得多，会把专名切碎
      （周星驰 → 周|星驰、金手指 → 金|手指、华为 → 华|为）。
      所以带了一份 lexicon.txt（从 jieba dict.txt 抽出的专名类词表，含词性），
      用它把被切碎的专名拼回来，并取到真实词性。
   ② 词典外的新词：jieba 靠 HMM（11MB 模型）能认出「安卓 / 谷歌 / 雷军」这类
      词典里没有的新词，浏览器里没有对应能力，只能当普通名词 → 会被长度规则挡掉。
      这是已知损失，宁可漏，也不放「这么 / 这样」这类虚词进来。

   实测（同一份 2026-09-03 导出，950 条）：
     大类划分 / 分桶 / 条目 / 逐月统计 —— 逐字段一致；
     进展线选词 —— 创作设计、生活家居、学习成长完全一致，
                  科技软件 11/14、影视 7/8、娱乐休闲 2/3 与 Python 版共有。
   ========================================================================== */
(function (global) {
  'use strict';

  var DAY = 86400;
  var GRAIN_SHORT_SPAN = 400;   // 跨度小于这个天数用「天」粒度

  /* ---------------------------------------------------------------- 大类体系
     与 build_data.py 的 LANES 同序、同词。
     顺序敏感：宽泛词（综合 / 娱乐）必须排在后面，先命中先生效。 */
  var LANES = [
    { key: 'tech',   name: '科技软件', color: '#6366F1', tags: ['数码', '计算机技术', '软件应用', '科学科普', '科技', '互联网'] },
    { key: 'design', name: '创作设计', color: '#0EA5E9', tags: ['设计·创意', '设计', '绘画', '手办', '模玩'] },
    { key: 'learn',  name: '学习成长', color: '#8B5CF6', tags: ['校园学习', '野生技能协会', '人文历史', '科学', '知识'] },
    { key: 'career', name: '职场理财', color: '#EC4899', tags: ['职业职场', '财经商业', '商业', '财经'] },
    { key: 'life',   name: '生活家居', color: '#22C55E', tags: ['日常', '美食', '家居房产', '时尚美妆', '动物', 'vlog', '生活'] },
    { key: 'travel', name: '旅行摄影', color: '#EAB308', tags: ['出行', '旅游', '旅行', '摄影', '风景'] },
    { key: 'film',   name: '影视',     color: '#DC2626', tags: ['影视', '预告·资讯', '短片', '小剧场', '综艺', '明星综合', '娱乐杂谈', '动漫杂谈', 'MV'] },
    { key: 'fun',    name: '娱乐休闲', color: '#F43F5E', tags: ['同人·手书', '搞笑', '综合', '音乐', '舞蹈', '游戏', '动画', '鬼畜', '娱乐'] },
    { key: 'relate', name: '情感关系', color: '#F97316', tags: ['情感', '心理'] }
  ];

  /* ---------------------------------------------------------------- 词表 */
  var STOP = toSet('\n' +
    '的 了 是 在 我 有 和 就 不 人 都 一 一个 上 也 很 到 说 要 去 你 会 着 没有 看 好 自己 这\n' +
    '他 她 它 们 那 这个 那个 什么 怎么 为什么 可以 因为 所以 但是 而且 如果 还是 就是 已经\n' +
    '视频 分享 教程 推荐 一些 我们 你们 他们 现在 今天 明天 昨天 大家 真的 其实 感觉\n' +
    '如何 怎样 最 更 太 非常 我的 你的 内容 方式 方法 问题 东西 时候 地方\n' +
    'up 主 up主 系列 合集 第 期 集 分钟 秒 小时 天 年 月 日 版本 更新 全新 首发 实测 体验\n' +
    'ai 人工智能 使用 需要 不需要 支持 功能 介绍 详解 入门 进阶 从零 手把手 保姆 级 快速\n');

  var GENERIC_EN = toSet('\n' +
    'all best pro plus new old app apps api sdk ui ux ar vr ai ml id ok no yes top the and for with\n' +
    'you your how what why my it is of in on to vs day week year one two mac win web pc tv ae ps mj\n' +
    'max mini lite free full real good great cool nice easy fast quick more most very just about from\n' +
    'howto how-to\n');

  var GENERIC_CN = toSet('\n' +
    '设计师 大佬 论文 建议 经验 记录 分享 产品 公司 工作 内容 方法 思路 计划 生活 人生 世界 时代\n' +
    '工具 平台 系统 功能 版本 效果 方案 项目 团队 用户 数据 学习 知识 技能 问题 需求 设计 教程\n' +
    '系列 合集 视频 博主 时间 时候 东西 事情 方式 过程 结果 原因 情况 行业 领域 方向 目标 能力\n' +
    '开发者 程序员 产品经理 运营 网友 普通人 年轻人 女生 男生 上班族 打工人 小白 新手 学生\n' +
    '小红书 抖音 哔哩哔哩 B站 微信 公众号 知乎 微博 头条 视频号 快手 淘宝 京东 拼多多 网易\n' +
    '干货 笔记 日常 推荐 指南 攻略 清单 盘点 总结 测评 开箱 种草 避雷 复盘 打卡\n' +
    '中字 字幕 解说 混剪 原声 片段 花絮 完整版 未删减 双语 高清 修复 重置 中文 英文\n' +
    '男主 女主 反派 结局 开头 结尾 名场面 神作 口碑 外星人 小姨子 黑客 妹子 老婆 女友 闺蜜\n');

  /* 2 字却实打实是主题的词，绕开「普通名词 ≥3 字」的长度规则 */
  var KEEP_CN = toSet('\n' +
    '电影 影片 短片 剧集 电视剧 综艺 纪录片 动画 喜剧 悬疑 科幻 港片 粤语\n' +
    '影评 观影 票房 影展 院线 预告 拉片 分镜 台词 剪辑 导演\n');

  var CANON = {
    ios: 'iOS', ipad: 'iPad', iphone: 'iPhone', imac: 'iMac',
    macos: 'macOS', macbook: 'MacBook', airpods: 'AirPods',
    github: 'GitHub', chatgpt: 'ChatGPT', openai: 'OpenAI', youtube: 'YouTube',
    figma: 'Figma', notion: 'Notion', midjourney: 'Midjourney', deepseek: 'DeepSeek',
    obsidian: 'Obsidian', android: 'Android', blender: 'Blender', canva: 'Canva',
    vibecoding: 'Vibe Coding', nextlevel: 'Next Level', dreamhouse: 'Dream House',
    citywalk: 'City Walk', roomtour: 'RoomTour', livephoto: 'Live Photo',
    adobe: 'Adobe', comfyui: 'ComfyUI', nestjs: 'NestJS', nodejs: 'Node.js',
    gpt4o: 'GPT-4o', gpt4: 'GPT-4', stitch: 'Stitch', figmamcp: 'Figma MCP'
  };

  function toSet(s) {
    var out = new Set();
    s.trim().split(/\s+/).forEach(function (w) { if (w) out.add(w); });
    return out;
  }

  /* ---------------------------------------------------------------- 分类 */
  var DESIGN_RE = /(?<![A-Za-z])UI(?![A-Za-z])|(?<![A-Za-z])UX(?![A-Za-z])|交互设计|界面设计|视觉设计|平面设计|品牌设计|包装设计|体验设计|服务设计|版式设计|字体设计|设计系统|设计规范|设计灵感|设计素材|设计工具|设计语言|设计稿|设计方案|视觉稿|配色|字体|排版|版式|插画|图标|动效|线框|海报|logo|Figma|Sketch|Canva|Illustrator|Photoshop|Blender|Dribbble|Behance/i;

  var BILI_DESIGN_RESCUE_TAGS = new Set(['数码', '计算机技术', '软件应用', '互联网', '科技', '科学科普']);

  var DESIGN_SUB_RULES = [
    ['UI/UX', /(?<![A-Za-z])UI(?![A-Za-z])|(?<![A-Za-z])UX(?![A-Za-z])|界面|交互|App|产品设计|设计系统|组件库|原型/i],
    ['平面品牌', /海报|平面|品牌|logo|包装|排版|版式|字体|视觉|配色|图标|色彩/i],
    ['插画绘画', /插画|绘画|手绘|漫画|原画|涂鸦/i],
    ['3D动效', /3D|三维|Blender|C4D|建模|渲染|动效|动画/i]
  ];

  function designSub(title) {
    title = title || '';
    for (var i = 0; i < DESIGN_SUB_RULES.length; i++) {
      if (DESIGN_SUB_RULES[i][1].test(title)) return DESIGN_SUB_RULES[i][0];
    }
    return '设计';
  }

  /* 技术类分区里混着的设计内容（Figma / UI / 海报 / Blender…）划到「创作设计」 */
  function laneOfBilibili(tag, title) {
    tag = tag || '综合';
    if (BILI_DESIGN_RESCUE_TAGS.has(tag) && DESIGN_RE.test(title || '')) return 'design';
    for (var i = 0; i < LANES.length; i++) {
      var ts = LANES[i].tags;
      for (var j = 0; j < ts.length; j++) {
        if (tag.indexOf(ts[j]) >= 0) return LANES[i].key;
      }
    }
    return 'fun';
  }

  /* ---------------------------------------------------------------- 分词
     jieba → Intl.Segmenter + 一份「专名类」精简词典（lexicon.txt）。

     为什么要词典：Intl.Segmenter 的中文词典比 jieba 小得多，会把专名切碎 ——
       「周星驰 → 周|星驰」「金手指 → 金|手指」「华为 → 华|为」。
     直接拿碎片去统计，「周星驰」就废了。所以：
       ① 用词典把被切碎的专名拼回来（只拼原文里紧挨着的片段）
       ② 顺便拿到真实词性 —— Python 版的 is_topic 靠词性把关，
          没有它，2 字虚词（这么 / 这样 / 完全 / 出来）会全部涌进进展线。 */
  var segmenter = (typeof Intl !== 'undefined' && Intl.Segmenter)
    ? new Intl.Segmenter('zh-Hans', { granularity: 'word' })
    : null;

  var LEXICON = new Map();      // 词 -> 词性

  function setLexicon(text) {
    LEXICON = new Map();
    if (!text) return 0;
    var lines = text.split('\n');
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];
      if (!ln) continue;
      var t = ln.indexOf('\t');
      if (t < 0) LEXICON.set(ln.trim(), 'nz');
      else LEXICON.set(ln.slice(0, t), ln.slice(t + 1).trim() || 'nz');
    }
    return LEXICON.size;
  }

  function cut(text) {
    text = String(text || '');
    if (!segmenter) return text.split(/\s+/);

    var raw = [];
    for (const s of segmenter.segment(text)) {
      if (s.isWordLike) raw.push({ s: s.segment, i: s.index });
    }
    if (!LEXICON.size) return raw.map(function (x) { return x.s; });

    /* 把被切碎的专名拼回来：只合并「原文里首尾相接」的片段，
       且拼接结果必须是词典里的词 —— 所以不会拼出不存在的组合。 */
    var out = [];
    var p = 0;
    while (p < raw.length) {
      var hit = 0;
      var maxN = Math.min(4, raw.length - p);
      for (var n = maxN; n >= 2; n--) {
        var joined = raw[p].s, contiguous = true;
        for (var q = 1; q < n; q++) {
          if (raw[p + q].i !== raw[p + q - 1].i + raw[p + q - 1].s.length) { contiguous = false; break; }
          joined += raw[p + q].s;
        }
        if (contiguous && LEXICON.has(joined)) { hit = n; out.push(joined); break; }
      }
      if (!hit) out.push(raw[p].s);
      p += hit || 1;
    }
    return out;
  }

  /* 词性：英文按 eng；词典里有就用真实词性；
     词典外一律当普通名词 n —— 于是 ≥3 字才够格进进展线，
     宁可漏掉几个词典外的 2 字新词（安卓 / 谷歌 那种 HMM 才能认出来的），
     也不放「这么 / 这样」这类虚词进来。 */
  function flagOf(word) {
    if (EN_WORD.test(word)) return 'eng';
    return LEXICON.get(word) || 'n';
  }

  var EN_PHRASE = /[A-Za-z][A-Za-z0-9.\-]*(?:\s+[A-Za-z][A-Za-z0-9.\-]*)+/g;
  var EN_WORD = /^[A-Za-z][A-Za-z0-9.\-]*$/;

  function isNoise(word) {
    if (!word || word.length < 2) return true;
    if (STOP.has(word.toLowerCase())) return true;
    /* Python 的 `[\d\W_]+` 等价于「一个字母都没有」。
       JS 的 \W 只认 ASCII，直接照抄会把中文全判成噪音，必须用 \p{L}。 */
    if (/^[^\p{L}]+$/u.test(word)) return true;
    return false;
  }

  function termKey(w) {
    if (w && /^[A-Za-z]/.test(w)) return w.replace(/\s+/g, '').toLowerCase();
    return w;
  }

  function bestForm(key, counter) {
    if (!counter || counter.size === 0) return '';
    if (CANON[key]) return CANON[key];
    var mx = 0;
    counter.forEach(function (v) { if (v > mx) mx = v; });
    var pool = [];
    counter.forEach(function (v, k) { if (v >= mx * 0.2) pool.push([k, v]); });
    if (!pool.length) counter.forEach(function (v, k) { pool.push([k, v]); });
    var best = pool[0];
    for (var i = 1; i < pool.length; i++) {
      var a = (pool[i][0].match(/[A-Z]/g) || []).length;
      var b = (best[0].match(/[A-Z]/g) || []).length;
      if (a > b || (a === b && pool[i][1] > best[1])) best = pool[i];
    }
    return best[0];
  }

  function isTopic(term) {
    var w = term[0], flag = term[2];
    if (GENERIC_EN.has(w.toLowerCase()) || GENERIC_CN.has(w)) return false;
    if (KEEP_CN.has(w)) return true;
    if (flag === 'eng') return w.length >= 3;
    if (flag === 'nz' || flag === 'nr' || flag === 'nt') return w.length >= 2;
    if (flag === 'n' || flag === 'vn' || flag === 'j') return w.length >= 3;
    return false;
  }

  /* ---------------------------------------------------------------- 热词 */
  function extractTerms(titles, topn, minCount) {
    if (minCount === undefined) minCount = 2;
    var score = new Map(), flags = new Map(), forms = new Map(), phraseKeys = new Set();

    function bump(key, weight, flag, raw) {
      score.set(key, (score.get(key) || 0) + weight);
      if (!flags.has(key)) flags.set(key, flag);
      if (!forms.has(key)) forms.set(key, new Map());
      var m = forms.get(key);
      m.set(raw, (m.get(raw) || 0) + 1);
    }

    for (var i = 0; i < titles.length; i++) {
      var title = String(titles[i] == null ? '' : titles[i]);

      /* 多词英文术语（Vibe Coding / AI Agent）整体保留，不拆成两个词 */
      var phrases = title.match(EN_PHRASE) || [];
      for (var p = 0; p < phrases.length; p++) {
        var phrase = phrases[p].trim();
        if (!(phrase.length >= 3 && phrase.length <= 26) || STOP.has(phrase.toLowerCase())) continue;
        var parts = phrase.toLowerCase().split(/\s+/);
        var allWeak = parts.every(function (x) { return GENERIC_EN.has(x) || x.length <= 2; });
        if (allWeak) continue;
        var pk = termKey(phrase);
        phraseKeys.add(pk);
        bump(pk, 3, 'eng', phrase);
      }

      var words = cut(title);
      for (var w = 0; w < words.length; w++) {
        var word = words[w].trim();
        if (isNoise(word)) continue;
        var key = termKey(word);
        var flag = flagOf(word);           // 英文 → eng；词典 → 真实词性；其余 → n
        /* 权重与 Python 一致：英文与 nz/nr/nt 记 3 分，n/j 记 2 分，其余 1 分 */
        var weight = (flag === 'eng' || flag === 'nz' || flag === 'nr' || flag === 'nt') ? 3
                   : (flag === 'n' || flag === 'j') ? 2 : 1;
        bump(key, weight, flag, word);
      }
    }

    /* 被高频词组覆盖的一部分要降权，避免 "Vibe"/"Coding" 与 "Vibe Coding" 重复出现 */
    phraseKeys.forEach(function (key) {
      var sc = score.get(key);
      if (sc === undefined || sc < 6) return;
      var raw = bestForm(key, forms.get(key)) || key;
      raw.split(/\s+/).forEach(function (part) {
        var pkk = termKey(part);
        if (pkk !== key && score.has(pkk) && score.get(pkk) <= sc * 1.5) {
          score.set(pkk, Math.trunc(score.get(pkk) * 0.3));
        }
      });
    });

    /* 平手按插入顺序 —— 与 Python Counter.most_common 一致，靠稳定排序实现 */
    var entries = [];
    score.forEach(function (v, k) { entries.push([k, v]); });
    entries.sort(function (a, b) { return b[1] - a[1]; });

    var out = [];
    for (var e = 0; e < entries.length && e < topn * 3; e++) {
      if (entries[e][1] < minCount) continue;
      var k2 = entries[e][0];
      out.push([bestForm(k2, forms.get(k2)) || k2, entries[e][1], flags.get(k2)]);
      if (out.length >= topn) break;
    }
    return out;
  }

  /* ---------------------------------------------------------------- 进展线 */
  function findProgress(buckets, minTotal, maxTopics, maxPerWeek) {
    if (minTotal === undefined) minTotal = 8;
    if (maxTopics === undefined) maxTopics = 14;
    if (maxPerWeek === undefined) maxPerWeek = 6;

    var total = new Map(), flags = new Map(), forms = new Map();
    var firstSeen = new Map(), spread = new Map(), lastIdx = new Map();
    var nBuckets = buckets.length || 1;

    for (var i = 0; i < buckets.length; i++) {
      var b = buckets[i];
      var inThis = new Set();
      for (var t = 0; t < b.terms.length; t++) {
        var w = b.terms[t][0], c = b.terms[t][1], flag = b.terms[t][2];
        var k = termKey(w);
        total.set(k, (total.get(k) || 0) + c);
        if (!forms.has(k)) forms.set(k, new Map());
        var fm = forms.get(k);
        fm.set(w, (fm.get(w) || 0) + c);
        if (!flags.has(k)) flags.set(k, flag);
        if (!firstSeen.has(k)) firstSeen.set(k, b);
        inThis.add(k);
      }
      inThis.forEach(function (kk) {
        spread.set(kk, (spread.get(kk) || 0) + 1);
        lastIdx.set(kk, i);
      });
    }

    var cands = [];
    total.forEach(function (c, k) {
      if (c < minTotal) return;
      /* 只在一期里蹦过一次的词，是「某条内容的元素」而不是「话题」 */
      if ((spread.get(k) || 0) < 2) return;
      /* 出现过又中途消失的，是某段时间碰巧刷到的题材，不是持续跟进的线 */
      if (lastIdx.get(k) < nBuckets * 0.5) return;
      var term = [bestForm(k, forms.get(k)) || k, c, flags.get(k)];
      if (!isTopic(term)) return;
      cands.push([firstSeen.get(k), term, spread.get(k)]);
    });

    /* 去冗余：若某词是另一个更强候选的子串（"聊天" ⊂ "聊天记录"），丢掉它 */
    var names = cands.map(function (ct) { return ct[1][0]; });
    cands = cands.filter(function (ct) {
      var word = ct[1][0];
      return !names.some(function (o) {
        return o !== word && o.length > word.length && o.indexOf(word) >= 0;
      });
    });

    /* 重要性 = 总权重 × 桶覆盖度；只看总权重会让「某期爆发一次的杂词」压过持续主线 */
    cands.sort(function (a, b) {
      return (b[1][1] * (1 + Math.log2(b[2] + 1))) - (a[1][1] * (1 + Math.log2(a[2] + 1)));
    });
    cands = cands.slice(0, maxTopics);

    var byBucket = new Map();
    cands.forEach(function (ct) {
      var key = ct[0].w;
      if (!byBucket.has(key)) byBucket.set(key, []);
      byBucket.get(key).push([ct[0], ct[1]]);
    });

    var keys = [];
    byBucket.forEach(function (v, k) { keys.push(k); });
    keys.sort(function (x, y) { return byBucket.get(x)[0][0].t - byBucket.get(y)[0][0].t; });

    var events = [];
    keys.forEach(function (wk) {
      var pairs = byBucket.get(wk);
      pairs.sort(function (p, q) { return q[1][1] - p[1][1]; });
      events.push({
        w: wk,
        t: pairs[0][0].t,
        topics: pairs.slice(0, maxPerWeek).map(function (p) { return p[1]; })
      });
    });
    return events;
  }

  /* ---------------------------------------------------------------- 时间
     桶一律按「本地日期」建（本地午夜），前端也按本地读 —— 用 UTC 会在东八区整体偏早一天。 */
  function pad2(n) { return String(n).padStart(2, '0'); }
  function ymd(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function monthOf(ts) { var d = new Date(ts * 1000); return d.getFullYear() + '-' + pad2(d.getMonth() + 1); }

  function isoWeek(d) {
    var t = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    var dow = (t.getDay() + 6) % 7;            // 周一 = 0
    t.setDate(t.getDate() - dow + 3);          // 移到本周四
    var isoYear = t.getFullYear();
    var jan4 = new Date(isoYear, 0, 4);
    var jan4dow = (jan4.getDay() + 6) % 7;
    var week1Mon = new Date(isoYear, 0, 4 - jan4dow);
    var week = Math.round((t.getTime() - week1Mon.getTime()) / (7 * 86400000)) + 1;
    return { year: isoYear, week: week };
  }

  function bucketOf(ts, grain) {
    var d = new Date(ts * 1000);
    if (grain === 'd') {
      var s0 = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      return [ymd(d), Math.floor(s0.getTime() / 1000)];
    }
    if (grain === 'm') {
      var s1 = new Date(d.getFullYear(), d.getMonth(), 1);
      return [d.getFullYear() + '-' + pad2(d.getMonth() + 1), Math.floor(s1.getTime() / 1000)];
    }
    var dow = (d.getDay() + 6) % 7;            // 周粒度对齐到周一，避免布局漂移
    var mon = new Date(d.getFullYear(), d.getMonth(), d.getDate() - dow);
    var s2 = new Date(mon.getFullYear(), mon.getMonth(), mon.getDate());
    var iso = isoWeek(d);
    return [iso.year + '-W' + pad2(iso.week), Math.floor(s2.getTime() / 1000)];
  }

  function pickGrain(timestamps) {
    if (!timestamps.length) return 'w';
    var lo = timestamps[0], hi = timestamps[0];
    for (var i = 1; i < timestamps.length; i++) {
      if (timestamps[i] < lo) lo = timestamps[i];
      if (timestamps[i] > hi) hi = timestamps[i];
    }
    return ((hi - lo) / DAY) < GRAIN_SHORT_SPAN ? 'd' : 'w';
  }

  /* ---------------------------------------------------------------- 封面
     B站图床支持在 URL 后拼 @ 参数直接取缩略图（120KB → 4KB）。 */
  function biliCover(url) {
    if (!url) return '';
    return url.split('@')[0].replace('http://', 'https://') + '@320w_200h_1c.webp';
  }

  /* ================================================================= 组装 */

  function buildFromHistory(history) {
    if (!history || !history.length) return null;

    var rows = [];
    for (var i = 0; i < history.length; i++) {
      var it = history[i];
      if (!it) continue;
      var ts = it.view_at;
      if (!ts) continue;
      var tag = it.tag_name || '综合';
      var title = String(it.title || '').trim();
      var lane = laneOfBilibili(tag, title);
      rows.push({
        ts: ts,
        lane: lane,
        sub: lane === 'design' ? designSub(title) : tag,
        item: {
          t: title,
          a: it.author_name || '',
          u: (it.history || {}).bvid || '',
          p: biliCover(it.cover),
          dur: it.duration || 0,
          prog: it.progress || 0
        }
      });
    }
    if (!rows.length) return null;

    var grain = pickGrain(rows.map(function (r) { return r.ts; }));
    var unit = grain === 'd' ? DAY : 7 * DAY;

    var lanes = new Map();
    rows.forEach(function (r) {
      var bk = bucketOf(r.ts, grain)[0];
      if (!lanes.has(r.lane)) lanes.set(r.lane, { buckets: new Map(), sub: new Map() });
      var L = lanes.get(r.lane);
      if (!L.buckets.has(bk)) L.buckets.set(bk, []);
      /* ts 必须留着：放大后每条内容都要按自己的时间落到横轴上，不能只挂在桶上 */
      L.buckets.get(bk).push(Object.assign({}, r.item, { sub: r.sub, ts: r.ts }));
      L.sub.set(r.sub, (L.sub.get(r.sub) || 0) + 1);
    });

    var outLanes = [];
    LANES.forEach(function (l) {
      var data = lanes.get(l.key);
      if (!data || !data.buckets.size) return;

      var entries = [];
      data.buckets.forEach(function (v, k) { entries.push([k, v]); });
      /* 按「插入顺序下的第一条」的 ts 排 —— 与 Python 建桶顺序一致，此时 items 还没排序 */
      entries.sort(function (a, b) { return a[1][0].ts - b[1][0].ts; });

      var buckets = [];
      var monthlyTitles = new Map();
      var monthlyTs = new Map();

      entries.forEach(function (pair) {
        var bk = pair[0], items = pair[1];
        items.sort(function (a, b) { return b.ts - a.ts; });
        var titles = items.map(function (x) { return x.t; });
        var bstart = bucketOf(items[0].ts, grain)[1];
        var mk = monthOf(items[0].ts);
        if (!monthlyTitles.has(mk)) monthlyTitles.set(mk, []);
        var arr = monthlyTitles.get(mk);
        for (var j = 0; j < titles.length; j++) arr.push(titles[j]);
        if (!monthlyTs.has(mk)) monthlyTs.set(mk, bstart);

        buckets.push({
          w: bk,
          t: bstart,
          n: items.length,
          terms: extractTerms(titles, 5),
          items: items            // 全量输出：放大后要看到每一条
        });
      });

      var monthly = [];
      var mkeys = [];
      monthlyTitles.forEach(function (v, k) { mkeys.push(k); });
      mkeys.sort();
      mkeys.forEach(function (m) {
        if (!monthlyTitles.get(m).length) return;
        var n = 0;
        for (var b = 0; b < buckets.length; b++) if (buckets[b].w.slice(0, 7) === m) n += buckets[b].n;
        monthly.push({
          m: m,
          t: monthlyTs.get(m),
          n: n,
          terms: extractTerms(monthlyTitles.get(m), 6)
        });
      });

      var subs = [];
      data.sub.forEach(function (v, k) { subs.push([k, v]); });
      subs.sort(function (a, b) { return b[1] - a[1]; });
      subs = subs.slice(0, 8);

      outLanes.push({
        key: l.key,
        name: l.name,
        color: l.color,
        total: buckets.reduce(function (s, b) { return s + b.n; }, 0),
        subs: subs,
        buckets: buckets,
        monthly: monthly,
        progress: findProgress(buckets)
      });
    });

    outLanes.sort(function (a, b) { return b.total - a.total; });

    var total = outLanes.reduce(function (s, l) { return s + l.total; }, 0);
    return {
      key: 'bilibili',
      label: 'B站历史记录',
      file: '插件实时数据',
      grain: grain,
      unit: unit,
      total: total,
      lanes: outLanes
    };
  }

  /* ================================================================= 启动 */

  function stamp() {
    var d = new Date();
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' +
           pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  function say(html) {
    var board = document.getElementById('board');
    if (board) board.innerHTML = '<div class="tl-msg">' + html + '</div>';
    ['stat-row', 'src-switch'].forEach(function (id) {
      var n = document.getElementById(id);
      if (n) n.innerHTML = '';
    });
  }

  function boot() {
    var tag = document.querySelector('.build-tag');
    if (tag) tag.textContent = '构建 ' + stamp();

    if (location.search.indexOf('embed=1') >= 0) {
      document.documentElement.classList.add('tl-embed');
    }

    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      say('这个页面要在扩展里打开才能读到数据。');
      return;
    }

    /* 先装词典（切碎专名的修复 + 词性都靠它），再读数据。
       词典缺了也能跑，只是中文专名会退化 —— 所以失败不阻断。 */
    loadLexicon().then(function () {
      chrome.storage.local.get(['bhc_cache'], function (res) {
        if (chrome.runtime && chrome.runtime.lastError) {
          say('读取本地数据失败：' + chrome.runtime.lastError.message);
          return;
        }
        var history = ((res && res.bhc_cache) || {}).history || [];
        var src = buildFromHistory(history);
        if (!src) {
          say('还没有历史记录数据。<br>先在「资料库」页点一次 <b>↻ 同步数据</b>，再回到这里。');
          return;
        }
        global.TIMELINE_DATA = { generatedAt: stamp(), sources: [src] };
        var s = document.createElement('script');
        s.src = 'app.js';
        document.body.appendChild(s);
      });
    });
  }

  function loadLexicon() {
    if (typeof fetch !== 'function') return Promise.resolve(0);
    return fetch('lexicon.txt')
      .then(function (r) { return r.ok ? r.text() : ''; })
      .then(function (t) { return setLexicon(t); })
      .catch(function () { return 0; });
  }

  /* 供本地校验复用（Node 里跑同一份数据、和 Python 产物比对） */
  global.TLBuild = {
    setLexicon: setLexicon,
    size: function () { return LEXICON.size; },
    buildFromHistory: buildFromHistory,
    extractTerms: extractTerms,
    laneOfBilibili: laneOfBilibili,
    bucketOf: bucketOf,
    pickGrain: pickGrain,
    LANES: LANES
  };

  if (typeof document !== 'undefined' && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    boot();
  }
})(typeof window !== 'undefined' ? window : globalThis);
