chrome.action.onClicked.addListener(() => {
  openDashboard();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'open_dashboard') {
    openDashboard();
    return false;
  }

  if (msg.action === 'proxy_fetch_request') {
    // Route through a live Bilibili tab
    chrome.tabs.query({ url: '*://*.bilibili.com/*' }, (tabs) => {
      const alive = tabs.filter(t => !t.url.includes('chrome-extension'));
      if (!alive.length) {
        sendResponse({ success: false, error: '未找到活跃的 B 站标签页，请先打开 bilibili.com 并确保已登录' });
        return;
      }
      chrome.tabs.sendMessage(alive[0].id, { action: 'proxy_fetch', url: msg.url }, (resp) => {
        sendResponse(resp || { success: false, error: '与 B 站标签页通信失败，请刷新那个标签页后重试' });
      });
    });
    return true; // async
  }

  if (msg.action === 'new_history_items') {
    // Forward sniffed items to the open Collector dashboard
    chrome.tabs.query({ url: chrome.runtime.getURL('dashboard.html') }, (tabs) => {
      tabs.forEach(t => chrome.tabs.sendMessage(t.id, msg));
    });
    return false;
  }

  return false;
});

function openDashboard() {
  const url = chrome.runtime.getURL('dashboard.html');
  chrome.tabs.query({ url }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.update(tabs[0].id, { active: true });
      chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      chrome.tabs.create({ url });
    }
  });
}

